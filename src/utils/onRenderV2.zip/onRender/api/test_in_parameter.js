// Test contoh penggunaan parameter "in" untuk bulk API calls

const testConfig = {
  "api": {
    "imageFromPk": {
      "url": "http://localhost:8004/api/part/",
      "in": {
        "id_in": "${graph.mo_order_shop.part_pk}"
      },
      "method": "GET",
      "headers": {
        "Authorization": "Basic YWRtaW46YWRtaW4="
      }
    }
  }
};

const testQueryData = [
  {
    "graph": {
      "mo_order_shop": [
        { "part_pk": 2000424, "product_name": "LED Blue" },
        { "part_pk": 2000104, "product_name": "Lens 90 deg" },
        { "part_pk": null, "product_name": "Kabel Buntung" },
        { "part_pk": 2000256, "product_name": "ELCO 4.7uF" },
        { "part_pk": 2000258, "product_name": "ELCO 6.8uF" }
      ]
    }
  }
];

// Expected result:
// URL: http://localhost:8004/api/part/?id_in=2000424,2000104,2000256,2000258
// Akan skip null values otomatis

console.log("=== Test Config ===");
console.log(JSON.stringify(testConfig, null, 2));

console.log("\n=== Test Query Data ===");
console.log(JSON.stringify(testQueryData, null, 2));

console.log("\n=== Expected API Call ===");
console.log("URL: http://localhost:8004/api/part/?id_in=2000424,2000104,2000256,2000258");
console.log("Method: GET");
console.log("Headers: Authorization: Basic YWRtaW46YWRtaW4=");

console.log("\n=== Advantages ===");
console.log("✅ Single API call instead of 4 separate calls");
console.log("✅ Better performance and less network overhead");
console.log("✅ Automatic filtering of null/undefined values");
console.log("✅ Supports any query parameter name (id_in, ids, part_ids, etc.)");

module.exports = { testConfig, testQueryData };
