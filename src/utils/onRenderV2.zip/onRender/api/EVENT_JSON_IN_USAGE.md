# Cara Menggunakan Parameter "in" pada Event.json

## 📋 STRUKTUR DASAR

```json
{
  "api": {
    "namaApi": {
      "url": "http://api-endpoint/resource/",
      "in": {
        "parameter_name": "${path.to.array.field}"
      },
      "method": "GET",
      "headers": {}
    }
  }
}
```

## 🎯 CONTOH PENGGUNAAN

### 1. Single Parameter "in"
```json
{
  "api": {
    "imageFromPk": {
      "url": "http://localhost:8004/api/part/",
      "in": {
        "id_in": "${graph.mo_order_shop.part_pk}"
      },
      "method": "GET",
      "headers": {
        "Authorization": "Basic YWRtaW46YWRtaW4="
      }
    }
  }
}
```

**Hasil API Call:**
```
GET http://localhost:8004/api/part/?id_in=20000,1111,22222,33333
```

### 2. Multiple Parameters "in"
```json
{
  "api": {
    "bulkProductData": {
      "url": "http://localhost:8004/api/product/bulk/",
      "in": {
        "part_ids": "${graph.mo_order_shop.part_pk}",
        "supplier_ids": "${graph.mo_order_shop.supplier_id}",
        "category_ids": "${graph.mo_order_shop.category_id}"
      },
      "method": "GET"
    }
  }
}
```

**Hasil API Call:**
```
GET http://localhost:8004/api/product/bulk/?part_ids=20000,1111,22222&supplier_ids=100,200,300&category_ids=1,2,3
```

### 3. Mixed Parameters (in + static)
```json
{
  "api": {
    "supplierBulk": {
      "url": "http://localhost:8004/api/supplier/bulk/",
      "in": {
        "supplier_ids": "${graph.mo_order_shop.supplier_id}"
      },
      "params": {
        "status": "active",
        "include_products": "true",
        "format": "json"
      },
      "method": "GET"
    }
  }
}
```

**Hasil API Call:**
```
GET http://localhost:8004/api/supplier/bulk/?supplier_ids=100,200,300&status=active&include_products=true&format=json
```

## 🗂️ CONTOH EVENT.JSON LENGKAP

```json
{
  "api": {
    "imageFromPk": {
      "url": "http://localhost:8004/api/part/",
      "in": {
        "id_in": "${graph.mo_order_shop.part_pk}"
      },
      "method": "GET",
      "headers": {
        "Authorization": "Basic YWRtaW46YWRtaW4="
      }
    },
    "supplierInfo": {
      "url": "http://localhost:8004/api/supplier/",
      "in": {
        "supplier_in": "${graph.mo_order_shop.supplier_id}"
      },
      "method": "GET",
      "headers": {
        "Authorization": "Basic YWRtaW46YWRtaW4="
      }
    },
    "categoryData": {
      "url": "http://localhost:8004/api/category/bulk/",
      "in": {
        "category_ids": "${graph.mo_order_shop.category_id}",
        "part_ids": "${graph.mo_order_shop.part_pk}"
      },
      "params": {
        "include_subcategories": "true"
      },
      "method": "GET"
    }
  },
  "components": [
    {
      "type": "datagrid",
      "key": "orderItems",
      "label": "Order Items",
      "columns": [
        {
          "components": [
            {
              "type": "textfield",
              "key": "part_pk",
              "label": "Part PK"
            },
            {
              "type": "textfield",
              "key": "product_name",
              "label": "Product Name"
            },
            {
              "type": "textfield",
              "key": "image",
              "label": "Image URL",
              "defaultValue": "unknown"
            },
            {
              "type": "textfield",
              "key": "supplier_name",
              "label": "Supplier Name",
              "defaultValue": "unknown"
            },
            {
              "type": "textfield",
              "key": "category_name",
              "label": "Category",
              "defaultValue": "unknown"
            }
          ]
        }
      ]
    }
  ]
}
```

## 🔍 TEMPLATE PATH YANG DIDUKUNG

### Format Template:
```
"${path.to.array.field}"
```

### Contoh Path:
- `"${graph.mo_order_shop.part_pk}"` → mengambil semua part_pk dari array mo_order_shop
- `"${data.items.product_id}"` → mengambil semua product_id dari array items
- `"${result.products.supplier_code}"` → mengambil semua supplier_code dari array products

### Data yang Didukung:
```json
{
  "graph": {
    "mo_order_shop": [
      { "part_pk": 20000, "supplier_id": 100, "category_id": 1 },
      { "part_pk": 1111, "supplier_id": 200, "category_id": 2 },
      { "part_pk": 22222, "supplier_id": 300, "category_id": 1 }
    ]
  }
}
```

## ⚙️ PARAMETER NAMES CONVENTION

### Recommended Naming:
- `id_in` untuk primary keys
- `part_ids` untuk part primary keys
- `supplier_ids` untuk supplier IDs
- `category_ids` untuk category IDs
- `status_in` untuk status values
- `code_in` untuk code values

### Contoh:
```json
{
  "in": {
    "id_in": "${graph.mo_order_shop.part_pk}",
    "supplier_ids": "${graph.mo_order_shop.supplier_id}",
    "status_in": "${graph.mo_order_shop.status}",
    "category_ids": "${graph.mo_order_shop.category_id}"
  }
}
```

## 🔧 FITUR AUTOMATIC

### 1. Auto Filtering
Nilai `null`, `undefined`, atau string kosong otomatis diabaikan:
```json
// Data:
[
  { "part_pk": 20000 },
  { "part_pk": null },     // akan diskip
  { "part_pk": 1111 },
  { "part_pk": "" }        // akan diskip
]

// Hasil: id_in=20000,1111
```

### 2. Auto Deduplication
Nilai duplikat otomatis dihilangkan:
```json
// Data:
[
  { "supplier_id": 100 },
  { "supplier_id": 200 },
  { "supplier_id": 100 }   // duplikat akan dihilangkan
]

// Hasil: supplier_ids=100,200
```

## 🚀 PERFORMA COMPARISON

### ❌ Tanpa "in" (Traditional):
```json
{
  "api": {
    "imageFromPk": {
      "url": "http://localhost:8004/api/part/${graph.mo_order_shop.part_pk}/",
      "method": "GET"
    }
  }
}
```
**Hasil:** 4 API calls terpisah (lambat)

### ✅ Dengan "in" (Bulk):
```json
{
  "api": {
    "imageFromPk": {
      "url": "http://localhost:8004/api/part/",
      "in": {
        "id_in": "${graph.mo_order_shop.part_pk}"
      },
      "method": "GET"
    }
  }
}
```
**Hasil:** 1 API call (cepat)

## 🔍 DEBUG & LOGGING

Ketika menggunakan parameter "in", sistem akan menampilkan log:
```
[resolveApiConfigs] Found "in" parameter for imageFromPk: { id_in: "${graph.mo_order_shop.part_pk}" }
[resolveApiConfigs] imageFromPk.id_in: 4 values -> "20000,1111,22222,33333"
[fetchApiData] Bulk API call detected with "in" parameters: ['id_in']
[fetchApiData] id_in: 4 values -> "20000,1111,22222,33333"
[fetchApiData] Making API call: GET http://localhost:8004/api/part/?id_in=20000,1111,22222,33333
```

## 🎯 BEST PRACTICES

1. **Gunakan nama parameter yang jelas:**
   ```json
   "id_in": "${graph.mo_order_shop.part_pk}"     // ✅ Good
   "ids": "${graph.mo_order_shop.part_pk}"       // ❌ Ambiguous
   ```

2. **Kombinasikan dengan parameter static:**
   ```json
   {
     "in": {
       "part_ids": "${graph.mo_order_shop.part_pk}"
     },
     "params": {
       "status": "active",
       "include_images": "true"
     }
   }
   ```

3. **Pastikan API endpoint mendukung bulk query:**
   - Server harus bisa handle parameter seperti `?id_in=1,2,3`
   - Database query harus dioptimasi untuk IN clause
   - Response format harus konsisten

## 🛠️ TROUBLESHOOTING

### Jika tidak ada API call:
1. Periksa format template path: `"${graph.mo_order_shop.part_pk}"`
2. Pastikan data array ada dan tidak kosong
3. Cek console log untuk error

### Jika API call tidak sesuai:
1. Periksa nama parameter di "in"
2. Pastikan API endpoint mendukung parameter tersebut
3. Cek URL yang dibentuk di console log

### Jika mapping gagal:
1. Pastikan response API mengandung field PK yang sesuai
2. Periksa format response API
3. Cek mapping logic di datagrid

---

**Parameter "in" siap digunakan untuk bulk API calls yang efisien!** 🚀
