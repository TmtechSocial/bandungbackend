# Parameter "in" untuk Bulk API Calls

## Overview
Parameter `"in"` memungkinkan Anda membuat **single API call** dengan multiple values dalam query string, alih-alih multiple API calls terpisah. Ini lebih efisien dan performant.

## Syntax

```json
{
  "api": {
    "apiName": {
      "url": "http://api-endpoint/resource/",
      "in": {
        "parameter_name": "${graph.table.field}"
      },
      "method": "GET",
      "headers": {}
    }
  }
}
```

## Contoh Penggunaan

### 1. Basic Usage
```json
{
  "api": {
    "imageFromPk": {
      "url": "http://localhost:8004/api/part/",
      "in": {
        "id_in": "${graph.mo_order_shop.part_pk}"
      },
      "method": "GET"
    }
  }
}
```

**Result:** `GET http://localhost:8004/api/part/?id_in=2000424,2000104,2000256,2000258`

### 2. Multiple Parameters
```json
{
  "api": {
    "productData": {
      "url": "http://api/products/",
      "in": {
        "part_ids": "${graph.mo_order_shop.part_pk}",
        "category_ids": "${graph.mo_order_shop.category_id}"
      },
      "method": "GET"
    }
  }
}
```

**Result:** `GET http://api/products/?part_ids=100,200,300&category_ids=1,2,3`

### 3. Custom Parameter Names
```json
{
  "api": {
    "supplierBulk": {
      "url": "http://api/suppliers/bulk/",
      "in": {
        "supplier_codes": "${graph.mo_order_shop.supplier_code}",
        "active_only": "true"
      },
      "method": "GET"
    }
  }
}
```

## Keuntungan

✅ **Performance**: 1 API call vs N API calls  
✅ **Network**: Mengurangi overhead network  
✅ **Server Load**: Lebih ringan untuk server API  
✅ **Caching**: Lebih mudah di-cache di level server  
✅ **Auto Filtering**: Otomatis skip null/undefined values  

## Perbandingan

### Tanpa Parameter "in" (Multiple Calls)
```
GET /api/part/2000424
GET /api/part/2000104  
GET /api/part/2000256
GET /api/part/2000258
Total: 4 API calls
```

### Dengan Parameter "in" (Single Call)
```
GET /api/part/?id_in=2000424,2000104,2000256,2000258
Total: 1 API call
```

## Schema Component

```json
{
  "key": "products",
  "type": "datagrid", 
  "components": [
    {
      "key": "image",
      "type": "textfield",
      "apiSource": {
        "source": "imageFromPk",
        "valueKey": "image"
      }
    }
  ]
}
```

## Data Mapping

Sistem akan otomatis mapping hasil API dengan data query berdasarkan field yang cocok (part_pk, id, dll). Field image yang tidak ada matching data API akan tetap bernilai "unknown".

## Catatan Implementasi

1. **Null Filtering**: Value null/undefined otomatis di-skip
2. **Dynamic Fields**: Mendukung field mapping dinamis
3. **Error Handling**: Jika API gagal, semua image tetap "unknown"
4. **Logging**: Detail logging untuk debugging

## Contoh Event.json Lengkap

```json
{
  "onRender": {
    "graph": {
      "method": "query",
      "endpoint": "http://localhost:9000/v1/graphql",
      "gqlQuery": "query MyQuery($proc_inst_id: [String!]) { mo_order_shop(where: {proc_inst_id: {_in: $proc_inst_id}}) { proc_inst_id invoice product_name sku_toko quantity_order part_pk } }",
      "variables": {
        "proc_inst_id": "instance_value"
      }
    },
    "api": {
      "imageFromPk": {
        "url": "http://localhost:8004/api/part/",
        "in": {
          "id_in": "${graph.mo_order_shop.part_pk}"
        },
        "method": "GET",
        "headers": {
          "Authorization": "Basic YWRtaW46YWRtaW4="
        }
      }
    }
  }
}
```

Dengan konfigurasi ini, sistem akan:
1. Query GraphQL untuk mendapatkan data mo_order_shop
2. Extract semua part_pk yang tidak null
3. Buat single API call: `GET /api/part/?id_in=2000424,2000104,2000256`
4. Map hasil API dengan data query berdasarkan part_pk
5. Update field image di datagrid sesuai hasil mapping
