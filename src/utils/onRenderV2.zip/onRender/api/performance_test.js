/**
 * PERFORMANCE TEST: Parameter "in" vs Traditional Methods
 * Menunjukkan perbedaan performa secara konkret
 */

// Simulasi data dengan berbagai ukuran
const testScenarios = [
  {
    name: "Small Dataset (5 items)",
    data: Array.from({length: 5}, (_, i) => ({part_pk: 20000 + i}))
  },
  {
    name: "Medium Dataset (20 items)", 
    data: Array.from({length: 20}, (_, i) => ({part_pk: 20000 + i}))
  },
  {
    name: "Large Dataset (50 items)",
    data: Array.from({length: 50}, (_, i) => ({part_pk: 20000 + i}))
  },
  {
    name: "Extra Large Dataset (100 items)",
    data: Array.from({length: 100}, (_, i) => ({part_pk: 20000 + i}))
  }
];

// Simulasi waktu API response berdasarkan metode
const simulateApiResponse = {
  traditional: {
    perCall: 150, // ms per individual call
    overhead: 50, // ms network overhead per call
    variability: 30 // ms random variation
  },
  sequential: {
    perCall: 150,
    overhead: 20, // less overhead due to parallel
    variability: 40,
    connectionLimit: 6 // browser connection limit
  },
  bulk: {
    baseTime: 100, // ms base time for bulk call
    perItem: 1.5, // ms additional per item
    overhead: 20, // ms single network overhead
    variability: 20
  }
};

// Test performance untuk setiap metode
function testPerformance(scenario) {
  const itemCount = scenario.data.length;
  
  console.log(`\n🧪 TESTING: ${scenario.name}`);
  console.log(`📊 Items to process: ${itemCount}`);
  console.log("=" .repeat(50));
  
  // Method 1: Traditional (Sequential individual calls)
  const traditionalTime = itemCount * (
    simulateApiResponse.traditional.perCall + 
    simulateApiResponse.traditional.overhead +
    Math.random() * simulateApiResponse.traditional.variability
  );
  
  // Method 2: Parallel calls (with connection limit)
  const parallelBatches = Math.ceil(itemCount / simulateApiResponse.sequential.connectionLimit);
  const parallelTime = parallelBatches * (
    simulateApiResponse.sequential.perCall + 
    simulateApiResponse.sequential.overhead +
    Math.random() * simulateApiResponse.sequential.variability
  );
  
  // Method 3: Bulk API with "in" parameter
  const bulkTime = 
    simulateApiResponse.bulk.baseTime + 
    (itemCount * simulateApiResponse.bulk.perItem) +
    simulateApiResponse.bulk.overhead +
    Math.random() * simulateApiResponse.bulk.variability;
  
  // Results
  console.log(`❌ Traditional Method:`);
  console.log(`   - ${itemCount} individual API calls`);
  console.log(`   - Total time: ${Math.round(traditionalTime)}ms`);
  console.log(`   - Network requests: ${itemCount}`);
  console.log(`   - Server DB queries: ${itemCount}`);
  
  console.log(`\n⚡ Parallel Method:`);
  console.log(`   - ${itemCount} parallel API calls (${parallelBatches} batches)`);
  console.log(`   - Total time: ${Math.round(parallelTime)}ms`);
  console.log(`   - Network requests: ${itemCount}`);
  console.log(`   - Server DB queries: ${itemCount}`);
  
  console.log(`\n✅ Bulk "in" Parameter:`);
  console.log(`   - 1 bulk API call`);
  console.log(`   - Total time: ${Math.round(bulkTime)}ms`);
  console.log(`   - Network requests: 1`);
  console.log(`   - Server DB queries: 1`);
  
  // Performance comparison
  const traditionalImprovement = Math.round(((traditionalTime - bulkTime) / traditionalTime) * 100);
  const parallelImprovement = Math.round(((parallelTime - bulkTime) / parallelTime) * 100);
  
  console.log(`\n🏆 PERFORMANCE GAINS:`);
  console.log(`   - ${traditionalImprovement}% faster than traditional`);
  console.log(`   - ${parallelImprovement}% faster than parallel`);
  console.log(`   - ${itemCount - 1} fewer API calls`);
  console.log(`   - ${itemCount - 1} fewer DB queries`);
  
  return {
    traditional: traditionalTime,
    parallel: parallelTime,
    bulk: bulkTime,
    traditionalImprovement,
    parallelImprovement
  };
}

// Test bandwidth usage
function testBandwidthUsage() {
  console.log("\n📡 BANDWIDTH USAGE COMPARISON");
  console.log("=" .repeat(50));
  
  const itemCount = 50;
  
  // Traditional: Multiple small requests
  const traditionalBandwidth = itemCount * (
    500 + // Average request size (headers + body)
    1500   // Average response size per item
  );
  
  // Bulk: Single large request
  const bulkBandwidth = 
    800 + // Request size (headers + larger query string)
    (itemCount * 1500); // Response size (same data, but single response)
  
  console.log(`Traditional method (${itemCount} calls):`);
  console.log(`  - Total bandwidth: ${Math.round(traditionalBandwidth/1024)}KB`);
  console.log(`  - HTTP overhead: ${itemCount * 500}B`);
  
  console.log(`\nBulk method (1 call):`);
  console.log(`  - Total bandwidth: ${Math.round(bulkBandwidth/1024)}KB`);
  console.log(`  - HTTP overhead: 800B`);
  
  const bandwidthSaving = Math.round(((traditionalBandwidth - bulkBandwidth) / traditionalBandwidth) * 100);
  console.log(`\n💾 Bandwidth savings: ${bandwidthSaving}%`);
}

// Test user experience impact
function testUserExperience() {
  console.log("\n👤 USER EXPERIENCE IMPACT");
  console.log("=" .repeat(50));
  
  const scenarios = [
    {name: "Mobile 3G", speed: 1.5}, // 1.5x slower
    {name: "Mobile 4G", speed: 1.2}, // 1.2x slower  
    {name: "WiFi", speed: 1.0},      // baseline
    {name: "Fast WiFi", speed: 0.8}  // 20% faster
  ];
  
  scenarios.forEach(scenario => {
    const itemCount = 30;
    
    // Traditional time with connection speed
    const traditionalTime = (itemCount * 150) * scenario.speed;
    
    // Bulk time with connection speed
    const bulkTime = (100 + itemCount * 1.5) * scenario.speed;
    
    console.log(`\n📱 ${scenario.name}:`);
    console.log(`   Traditional: ${Math.round(traditionalTime)}ms (${Math.round(traditionalTime/1000)}s)`);
    console.log(`   Bulk "in":   ${Math.round(bulkTime)}ms (${Math.round(bulkTime/1000)}s)`);
    
    const improvement = Math.round(((traditionalTime - bulkTime) / traditionalTime) * 100);
    console.log(`   Improvement: ${improvement}%`);
  });
}

// Run all tests
console.log("🚀 PERFORMANCE COMPARISON: Parameter 'in' vs Traditional Methods");
console.log("=" .repeat(70));

// Test different dataset sizes
const results = testScenarios.map(scenario => testPerformance(scenario));

// Summary
console.log("\n📈 SUMMARY OF ALL TESTS");
console.log("=" .repeat(50));

const avgTraditionalImprovement = Math.round(
  results.reduce((sum, r) => sum + r.traditionalImprovement, 0) / results.length
);
const avgParallelImprovement = Math.round(
  results.reduce((sum, r) => sum + r.parallelImprovement, 0) / results.length
);

console.log(`Average improvement vs traditional: ${avgTraditionalImprovement}%`);
console.log(`Average improvement vs parallel: ${avgParallelImprovement}%`);
console.log(`Best use case: Large datasets (50+ items)`);
console.log(`Performance gets better with more items!`);

// Additional tests
testBandwidthUsage();
testUserExperience();

console.log("\n🎯 CONCLUSION:");
console.log("✅ Parameter 'in' is consistently faster across all scenarios");
console.log("✅ Bigger datasets = bigger performance gains");
console.log("✅ Better user experience on all connection types");
console.log("✅ Reduced server load and bandwidth usage");
console.log("✅ More reliable (single point of failure vs multiple)");

console.log("\n🏆 WINNER: Parameter 'in' for bulk API calls!");
