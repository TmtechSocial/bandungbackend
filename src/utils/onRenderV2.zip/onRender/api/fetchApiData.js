const axios = require("axios");

// Optimization: Create axios instance with better defaults
const axiosInstance = axios.create({
  timeout: 100000, // 10 seconds timeout instead of 1000 seconds
  maxRedirects: 5,
  maxContentLength: 50 * 1024 * 1024, // 50MB limit
});

// Optimization: Add request/response interceptors for logging slow requests
axiosInstance.interceptors.request.use(
  (config) => {
    config.metadata = { startTime: Date.now() };
    return config;
  }
);

axiosInstance.interceptors.response.use(
  (response) => {
    const duration = Date.now() - response.config.metadata.startTime;
    if (duration > 3000) { // Log requests taking more than 3 seconds
      console.warn(`Slow API request: ${response.config.url} took ${duration}ms`);
    }
    return response;
  },
  (error) => {
    if (error.config && error.config.metadata) {
      const duration = Date.now() - error.config.metadata.startTime;
      console.error(`Failed API request: ${error.config.url} failed after ${duration}ms`);
    }
    return Promise.reject(error);
  }
);

// --- API Result Cache ---
// Cache dengan konfigurasi per API
const apiResultCache = new Map();
const API_CACHE_TTL = 5 * 60 * 1000; // 5 menit

// Konfigurasi cache per API (bisa didefinisikan oleh user)
const cacheConfig = {
  // Master data - cache lebih lama karena jarang berubah
  // imageFromPk: { enabled: true, ttl: 10 * 60 * 1000 }, // 10 menit
  // supplierBulk: { enabled: true, ttl: 15 * 60 * 1000 }, // 15 menit
  // categoryData: { enabled: true, ttl: 20 * 60 * 1000 }, // 20 menit
  
  // // Transactional data - cache pendek atau tidak di-cache
  // orderStatus: { enabled: false }, // tidak di-cache
  // stockLevel: { enabled: true, ttl: 30 * 1000 }, // 30 detik
  // userSession: { enabled: false }, // tidak di-cache
  
  // // Default untuk API yang tidak terdefinisi
  // default: { enabled: true, ttl: API_CACHE_TTL } // 5 menit
};

function getApiCacheKey(apiDetails, additionalData, formData, event, apiName) {
  // Key: url + method + params + data + path + headers + apiName
  return JSON.stringify({
    apiName, // tambahkan apiName untuk identifikasi
    url: apiDetails.url,
    method: apiDetails.method || 'GET',
    headers: apiDetails.headers || {},
    params: apiDetails.params || {},
    data: apiDetails.data || {},
    path: apiDetails.path || {},
    query: apiDetails.query || {},
    additionalData,
    formData,
    event,
  });
}

async function fetchApiData(apiDetails, additionalData = {}, formData = {}, event = {}, apiName = 'unknown') {
  try {
    // Check cache configuration untuk API ini dengan fallback yang aman
    const config = cacheConfig[apiName] || cacheConfig.default || { enabled: true, ttl: API_CACHE_TTL };
    const isCacheEnabled = config.enabled || false;
    const cacheTTL = config.ttl || API_CACHE_TTL;
    
    console.log(`[fetchApiData] API [${apiName}] cache config:`, { enabled: isCacheEnabled, ttl: cacheTTL });
    
    // Cache logic jika enabled
    let cacheKey;
    if (isCacheEnabled) {
      cacheKey = getApiCacheKey(apiDetails, additionalData, formData, event, apiName);
      const cached = apiResultCache.get(cacheKey);
      
      if (cached && Date.now() - cached.timestamp < cacheTTL) {
        console.log(`[fetchApiData] Cache hit for API [${apiName}] - saved ${Date.now() - cached.timestamp}ms`);
        return cached.data;
      }
      
      if (cached) {
        console.log(`[fetchApiData] Cache expired for API [${apiName}] - refreshing`);
      }
    }
    
    let finalUrl = apiDetails.url;
    const {
      method = "GET",
      headers = {},
      params = {},
      data = {},
      path = {},
      query = {}, // support query param override
      responseKey = null, // tambahan: field untuk menentukan key response yang diinginkan
    } = apiDetails;
    
    const substitutionData = {
      ...formData,
      ...additionalData,
      ...event,
    };
    
    // Replace ${key} in strings
    const replaceTemplate = (str) =>
      str.replace(/\$\{([^}]+)\}/g, (_, key) => substitutionData[key] ?? "");
    
    // Replace path parameters :key in URL
    if (path) {
      Object.entries(path).forEach(([key, rawValue]) => {
        let value = rawValue;
        if (typeof value === "string" && value.includes("${")) {
          const match = value.match(/\$\{([^}]+)\}/);
          if (match) {
            const templateVar = match[1];
            value = substitutionData[templateVar] ?? "";
          }
        }
        finalUrl = finalUrl.replace(`:${key}`, value);
      });
    }
    
    // Apply template substitution on query/params
    const processedParams = Object.fromEntries(
      Object.entries({ ...params, ...query }).map(([k, v]) => [
        k,
        typeof v === "string" ? replaceTemplate(v) : v,
      ])
    );
    
    // Log if this appears to be a bulk API call (parameter "in" converted to params)
    const bulkParams = Object.keys(processedParams).filter(key => key.includes('_in'));
    if (bulkParams.length > 0) {
      console.log(`[fetchApiData] Bulk API call detected with "in" parameters:`, bulkParams);
      bulkParams.forEach(param => {
        const values = processedParams[param];
        if (typeof values === 'string' && values.includes(',')) {
          const valueCount = values.split(',').length;
          console.log(`[fetchApiData] ${param}: ${valueCount} values -> "${values.substring(0, 50)}${values.length > 50 ? '...' : ''}"`);
        }
      });
    }
    
    // Apply template substitution on body data
    const processedData =
      typeof data === "string"
        ? replaceTemplate(data)
        : Object.fromEntries(
            Object.entries(data).map(([k, v]) => [
              k,
              typeof v === "string" ? replaceTemplate(v) : v,
            ])
          );
    
    // Log API call details (especially for bulk calls)
    // Build URL manually to avoid encoding commas in comma-separated values
    let fullUrl = finalUrl;
    if (Object.keys(processedParams).length > 0) {
      const paramPairs = Object.entries(processedParams).map(([key, value]) => {
        // For parameters that contain commas (like id_in), don't encode the commas
        if (typeof value === 'string' && value.includes(',') && key.includes('_in')) {
          return `${encodeURIComponent(key)}=${value}`;
        }
        return `${encodeURIComponent(key)}=${encodeURIComponent(value)}`;
      });
      fullUrl = `${finalUrl}${paramPairs.join('&')}`;
    }
    console.log(`[fetchApiData] Making API call: ${method} ${fullUrl}`);
    
    // Optimization: Use optimized axios instance
    const response = await axiosInstance({
      method,
      url: finalUrl,
      headers,
      params: processedParams,
      data: processedData,
    });

    // Fleksibilitas dalam mengembalikan data response
    let result;
    if (responseKey) {
      result = response.data[responseKey];
    } else if (response.data.results !== undefined) {
      result = response.data.results;
    } else {
      result = response.data;
    }
    
    // Simpan ke cache jika enabled
    if (isCacheEnabled && cacheKey) {
      apiResultCache.set(cacheKey, {
        data: result,
        timestamp: Date.now()
      });
      console.log(`[fetchApiData] API [${apiName}] result cached for ${cacheTTL/1000}s`);
    }
    
    return result;
    
  } catch (error) {
    console.error(`[fetchApiData] Error fetching API [${apiName}]:`, error.message);
    console.error(`[fetchApiData] Full error for API [${apiName}]:`, error.response?.data || error);
    console.error(`[fetchApiData] Stack trace:`, error.stack);
    return null;
  }
}

module.exports = fetchApiData;


