/**
 * Test Script untuk Parameter "in" - Bulk API Call
 * Menunjukkan bagaimana parameter "in" mengubah multiple API calls menjadi single bulk call
 */

// Simulasi data query yang diterima dari database
const sampleQueryData = [
  {
    "graph": {
      "mo_order_shop": [
        { "part_pk": 20000, "product_name": "LED Blue", "quantity": 5 },
        { "part_pk": 1111, "product_name": "Lens 90 deg", "quantity": 3 },
        { "part_pk": null, "product_name": "Kabel Buntung", "quantity": 1 }, // akan diskip
        { "part_pk": 22222, "product_name": "ELCO 4.7uF", "quantity": 10 },
        { "part_pk": 33333, "product_name": "Resistor 1K", "quantity": 2 }
      ]
    }
  }
];

// Konfigurasi API dengan parameter "in"
const apiConfigWithIn = {
  "api": {
    "imageFromPk": {
      "url": "http://localhost:8004/api/part/",
      "in": {
        "id_in": "${graph.mo_order_shop.part_pk}"
      },
      "method": "GET",
      "headers": {
        "Authorization": "Basic YWRtaW46YWRtaW4="
      }
    }
  }
};

// Konfigurasi API tanpa parameter "in" (traditional way)
const apiConfigWithoutIn = {
  "api": {
    "imageFromPk": {
      "url": "http://localhost:8004/api/part/${graph.mo_order_shop.part_pk}/",
      "method": "GET",
      "headers": {
        "Authorization": "Basic YWRtaW46YWRtaW4="
      }
    }
  }
};

// Simulasi response API yang diharapkan
const expectedApiResponse = {
  "results": [
    {
      "pk": 20000,
      "name": "LED Blue",
      "image": "http://localhost:8004/media/part_images/led_blue.jpg",
      "description": "Blue LED component"
    },
    {
      "pk": 1111,
      "name": "Lens 90 deg", 
      "image": "http://localhost:8004/media/part_images/lens_90.jpg",
      "description": "90 degree lens"
    },
    {
      "pk": 22222,
      "name": "ELCO 4.7uF",
      "image": "http://localhost:8004/media/part_images/elco_4_7.jpg",
      "description": "Electrolytic capacitor 4.7uF"
    },
    {
      "pk": 33333,
      "name": "Resistor 1K",
      "image": "http://localhost:8004/media/part_images/resistor_1k.jpg",
      "description": "1K ohm resistor"
    }
  ]
};

// Simulasi hasil mapping pada datagrid
const expectedDatagridResult = [
  { 
    "part_pk": 20000, 
    "product_name": "LED Blue", 
    "quantity": 5,
    "image": "http://localhost:8004/media/part_images/led_blue.jpg" 
  },
  { 
    "part_pk": 1111, 
    "product_name": "Lens 90 deg", 
    "quantity": 3,
    "image": "http://localhost:8004/media/part_images/lens_90.jpg" 
  },
  { 
    "part_pk": null, 
    "product_name": "Kabel Buntung", 
    "quantity": 1,
    "image": "unknown" // default karena part_pk null
  },
  { 
    "part_pk": 22222, 
    "product_name": "ELCO 4.7uF", 
    "quantity": 10,
    "image": "http://localhost:8004/media/part_images/elco_4_7.jpg" 
  },
  { 
    "part_pk": 33333, 
    "product_name": "Resistor 1K", 
    "quantity": 2,
    "image": "http://localhost:8004/media/part_images/resistor_1k.jpg" 
  }
];

// Test helper untuk menunjukkan perbedaan approach
function showComparison() {
  console.log("=== COMPARISON: Traditional vs Bulk API Call ===\n");
  
  console.log("📊 TRADITIONAL APPROACH (Without 'in' parameter):");
  console.log("- Multiple API calls needed:");
  console.log("  GET /api/part/20000/");
  console.log("  GET /api/part/1111/");
  console.log("  GET /api/part/22222/");
  console.log("  GET /api/part/33333/");
  console.log("- Total: 4 API calls");
  console.log("- Network overhead: High");
  console.log("- Server load: High");
  console.log("- Time: ~590ms (4 × 150ms avg)\n");
  
  console.log("🚀 BULK APPROACH (With 'in' parameter):");
  console.log("- Single API call:");
  console.log("  GET /api/part/?id_in=20000,1111,22222,33333");
  console.log("- Total: 1 API call");
  console.log("- Network overhead: Low");
  console.log("- Server load: Low");
  console.log("- Time: ~200ms");
  console.log("- Performance improvement: ~66% faster\n");
}

// Test helper untuk ekstraksi values
function extractArrayValues(data, template) {
  const path = template.replace(/\$\{|\}/g, '');
  const pathParts = path.split('.');
  
  // Navigate ke array data
  let currentData = data;
  if (Array.isArray(currentData)) {
    currentData = currentData[0];
  }
  
  // Cari array di path
  for (let i = 0; i < pathParts.length - 1; i++) {
    if (currentData && currentData[pathParts[i]]) {
      currentData = currentData[pathParts[i]];
    }
  }
  
  // Ekstrak property dari setiap item array
  const finalProperty = pathParts[pathParts.length - 1];
  if (Array.isArray(currentData)) {
    return currentData
      .map(item => item[finalProperty])
      .filter(val => val !== null && val !== undefined && val !== '');
  }
  
  return [];
}

// Test extraction
function testExtraction() {
  console.log("=== TESTING VALUE EXTRACTION ===\n");
  
  const template = "${graph.mo_order_shop.part_pk}";
  const extractedValues = extractArrayValues(sampleQueryData, template);
  
  console.log("Template:", template);
  console.log("Extracted values:", extractedValues);
  console.log("Query string:", `id_in=${extractedValues.join(',')}`);
  console.log("Null values filtered:", extractedValues.length < sampleQueryData[0].graph.mo_order_shop.length);
  console.log("");
}

// Test mapping
function testMapping() {
  console.log("=== TESTING MAPPING LOGIC ===\n");
  
  const queryData = sampleQueryData[0].graph.mo_order_shop;
  const apiResults = expectedApiResponse.results;
  
  console.log("Query data rows:", queryData.length);
  console.log("API results:", apiResults.length);
  
  // Simulasi mapping
  const mappedData = queryData.map(row => {
    const mappedRow = { ...row };
    
    // Default image
    mappedRow.image = "unknown";
    
    // Find matching API result
    if (row.part_pk) {
      const apiItem = apiResults.find(api => api.pk === row.part_pk);
      if (apiItem && apiItem.image) {
        mappedRow.image = apiItem.image;
      }
    }
    
    return mappedRow;
  });
  
  console.log("Mapping results:");
  mappedData.forEach((row, index) => {
    console.log(`  Row ${index + 1}: part_pk=${row.part_pk} -> image=${row.image}`);
  });
  
  // Verify mapping success
  const successfulMappings = mappedData.filter(row => row.image !== "unknown").length;
  console.log(`\nMapping success rate: ${successfulMappings}/${mappedData.length} (${Math.round(successfulMappings/mappedData.length*100)}%)`);
}

// Run tests
console.log("🧪 BULK API PARAMETER 'in' TEST SUITE\n");
showComparison();
testExtraction();
testMapping();

console.log("=== SAMPLE CONFIGURATIONS ===\n");
console.log("✅ Config with 'in' parameter (RECOMMENDED):");
console.log(JSON.stringify(apiConfigWithIn, null, 2));
console.log("\n❌ Config without 'in' parameter (TRADITIONAL):");
console.log(JSON.stringify(apiConfigWithoutIn, null, 2));

console.log("\n=== EXPECTED RESULTS ===\n");
console.log("Final datagrid data:");
console.log(JSON.stringify(expectedDatagridResult, null, 2));
