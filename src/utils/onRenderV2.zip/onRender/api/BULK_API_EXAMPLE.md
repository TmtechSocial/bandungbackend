# Contoh Penggunaan Parameter "in" untuk Bulk API Call

## Skenario
Anda memiliki datagrid dengan data order yang berisi field `part_pk`, dan Anda ingin mengambil data gambar untuk semua part tersebut dalam **satu API call** (bulk) alih-alih multiple API calls terpisah.

## Data yang Diterima dari Query
```json
{
  "graph": {
    "mo_order_shop": [
      { "part_pk": 20000, "product_name": "LED Blue", "quantity": 5 },
      { "part_pk": 1111, "product_name": "Lens 90 deg", "quantity": 3 },
      { "part_pk": 22222, "product_name": "ELCO 4.7uF", "quantity": 10 },
      { "part_pk": 33333, "product_name": "Resistor 1K", "quantity": 2 }
    ]
  }
}
```

## Konfigurasi API dengan Parameter "in"
```json
{
  "api": {
    "imageFromPk": {
      "url": "http://localhost:8004/api/part/",
      "in": {
        "id_in": "${graph.mo_order_shop.part_pk}"
      },
      "method": "GET",
      "headers": {
        "Authorization": "Basic YWRtaW46YWRtaW4="
      }
    }
  }
}
```

## Hasil API Call
Sistem akan melakukan **single API call**:
```
GET http://localhost:8004/api/part/?id_in=20000,1111,22222,33333
Authorization: Basic YWRtaW46YWRtaW4=
```

## Response API yang Diharapkan
```json
{
  "results": [
    {
      "pk": 20000,
      "name": "LED Blue",
      "image": "http://localhost:8004/media/part_images/led_blue.jpg",
      "description": "Blue LED component"
    },
    {
      "pk": 1111,
      "name": "Lens 90 deg",
      "image": "http://localhost:8004/media/part_images/lens_90.jpg",
      "description": "90 degree lens"
    },
    {
      "pk": 22222,
      "name": "ELCO 4.7uF",
      "image": "http://localhost:8004/media/part_images/elco_4_7.jpg",
      "description": "Electrolytic capacitor 4.7uF"
    },
    {
      "pk": 33333,
      "name": "Resistor 1K",
      "image": "http://localhost:8004/media/part_images/resistor_1k.jpg",
      "description": "1K ohm resistor"
    }
  ]
}
```

## Mapping pada Datagrid
Setelah mendapat response API, sistem akan melakukan mapping otomatis:
- Data datagrid dengan `part_pk: 20000` akan mendapat `image: "http://localhost:8004/media/part_images/led_blue.jpg"`
- Data datagrid dengan `part_pk: 1111` akan mendapat `image: "http://localhost:8004/media/part_images/lens_90.jpg"`
- Data datagrid dengan `part_pk: 22222` akan mendapat `image: "http://localhost:8004/media/part_images/elco_4_7.jpg"`
- Data datagrid dengan `part_pk: 33333` akan mendapat `image: "http://localhost:8004/media/part_images/resistor_1k.jpg"`

## Keuntungan

### Tanpa Parameter "in" (4 API calls)
```
GET /api/part/20000  -> 150ms
GET /api/part/1111   -> 120ms  
GET /api/part/22222  -> 180ms
GET /api/part/33333  -> 140ms
Total: 590ms + network overhead
```

### Dengan Parameter "in" (1 API call)
```
GET /api/part/?id_in=20000,1111,22222,33333  -> 200ms
Total: 200ms
```

**Penghematan:** 66% lebih cepat + mengurangi load server

## Implementasi pada Schema Datagrid

```json
{
  "type": "datagrid",
  "key": "orderItems",
  "columns": [
    {
      "components": [
        {
          "type": "textfield",
          "key": "product_name",
          "label": "Product Name"
        },
        {
          "type": "textfield", 
          "key": "image",
          "label": "Image URL",
          "defaultValue": "unknown"
        }
      ]
    }
  ]
}
```

## Fitur Otomatis yang Tersedia

1. **Auto Filtering**: Nilai `null`, `undefined`, atau `""` otomatis diskip
2. **Dynamic Mapping**: Mapping berdasarkan field PK yang dinamis 
3. **Fallback**: Jika mapping gagal, field image tetap "unknown"
4. **Logging**: Detail logging untuk debugging
5. **Performance**: Optimasi untuk bulk data

## Troubleshooting

### Jika API tidak mengembalikan data:
- Periksa apakah endpoint mendukung parameter `id_in`
- Periksa format response apakah sesuai dengan yang diharapkan
- Periksa log console untuk detail error

### Jika mapping tidak sesuai:
- Periksa apakah field PK pada response API sesuai dengan field PK pada query data
- Periksa log console untuk detail mapping process

### Jika performance masih lambat:
- Periksa apakah API endpoint sudah dioptimasi untuk bulk query
- Pertimbangkan untuk menggunakan pagination jika data terlalu besar
