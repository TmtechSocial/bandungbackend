// Optimized handleRender.js with NO caching and parallel processing
const {
  configureProcess,
  configureQuery,
} = require("../../controller/controllerConfig");
const { getMember } = require("../ldap/ldapHierarki");

const setupDependencies = require("./event/setupDependencies");
const setupHandlers = require("./event/setupHandlers");
const loadInitialApiData = require("./api/loadInitialApiData");
const { processQueryData } = require("./utils/queryProcessor");
const processComponents = require("./process/processComponents");
const createFormState = require("./formState");

// Semua logika cache DIHAPUS

async function dynamicRender(fastify, process, instance, session) {
  const startTime = Date.now();
  console.log(
    `Starting dynamicRender for process: ${process}, instance: ${instance}`
  );

  try {
    // Step 1: getMember boleh paralel sejak awal
    const memberPromise = getMember(fastify, session);

    // Step 2: Ambil config (schema & event) - SELALU FRESH
    let getSchema, getEvent, onRenderDetails, schema, otherEvent, processedQueryData, formState, memberResult;
    console.log(`Fetching config for ${process}...`);
    const configResult = await configureProcess(fastify, process);
    getSchema = getEvent = configResult;
    console.log(`Config loaded for ${process} (${Date.now() - startTime}ms)`);

    schema = Array.isArray(instance)
      ? getSchema[0].schema_grid_json
      : getSchema[0].schema_json;

    const { onRender: renderEvent, ...restEvent } = getEvent[0].event_json;
    otherEvent = restEvent;
    onRenderDetails = renderEvent;

    if (instance && (Array.isArray(instance) ? instance.length > 0 : true)) {
      const { graph } = renderEvent;
      if (graph && graph.variables) {
        onRenderDetails = {
          ...renderEvent,
          graph: {
            ...graph,
            variables: {
              ...graph.variables,
              proc_inst_id: instance,
            },
          },
        };
      }
    }

    console.log(`Creating form state (${Date.now() - startTime}ms)`);
    formState = createFormState(schema, session);
    setupDependencies(schema, formState);

    // Step 3: Jalankan configureQuery
    console.log(`Configuring query (${Date.now() - startTime}ms)`);
    const responseQuery = await configureQuery(fastify, onRenderDetails);
    if (!responseQuery.data) {
      throw new Error("Failed to configure process");
    }
    processedQueryData = processQueryData(responseQuery.data);

    // Step 4: Setelah semua dependensi siap, baru loadInitialApiData
    console.log(`Loading API data (${Date.now() - startTime}ms)`);
    console.log(`[handleRender] API configs to load:`, JSON.stringify(onRenderDetails.api, null, 2));
    
    // Check for "in" parameter usage
    if (onRenderDetails.api) {
      Object.entries(onRenderDetails.api).forEach(([key, config]) => {
        if (config.in) {
          console.log(`[handleRender] API [${key}] uses "in" parameter for bulk calls:`, config.in);
        }
      });
    }
    
    console.log(`[handleRender] ProcessedQueryData structure:`, processedQueryData?.map(item => ({
      type: item.sqlQuery ? 'SQL' : 'Graph',
      table: item.sqlQuery?.table || Object.keys(item.graph || {}),
      rowCount: item.sqlQuery?.data?.length || Object.values(item.graph || {})[0]?.length,
      sampleFields: item.sqlQuery?.data?.[0] ? Object.keys(item.sqlQuery.data[0]) : 
                   Object.values(item.graph || {})[0]?.[0] ? Object.keys(Object.values(item.graph)[0][0]) : []
    })));
    
    const apiDataResult = await loadInitialApiData(
      onRenderDetails.api,
      schema,
      processedQueryData,
      formState,
      session
    );
    
    console.log(`[handleRender] API data loaded. FormState API results:`, Object.keys(formState.apiResults || {}));
    if (formState.apiResults) {
      Object.entries(formState.apiResults).forEach(([key, value]) => {
        if (Array.isArray(value)) {
          console.log(`[handleRender] API Result [${key}]: Array(${value.length})`);
          if (value.length > 0) {
            console.log(`[handleRender] API Result [${key}] sample fields:`, Object.keys(value[0]));
            console.log(`[handleRender] API Result [${key}] first item:`, value[0]);
          }
        } else {
          console.log(`[handleRender] API Result [${key}]:`, typeof value, value);
        }
      });
    }

    // Step 5: Tunggu memberResult jika belum
    memberResult = await memberPromise;

    console.log(`Processing components (${Date.now() - startTime}ms)`);
    console.log(`[handleRender] Schema components count:`, schema.components?.length || 0);
    console.log(`[handleRender] Processing datagrid components...`);
    
    await processComponents(
      schema.components,
      processedQueryData,
      formState,
      session,
      onRenderDetails.api,
      memberResult
    );
    
    console.log(`[handleRender] Components processing completed`);
    // Log final schema state for datagrid
    const datagridComponent = schema.components?.find(c => c.type === 'datagrid');
    if (datagridComponent) {
      console.log(`[handleRender] Final datagrid defaultValue count:`, datagridComponent.defaultValue?.length || 0);
      
      // Log mapping status untuk setiap row
      const mappingStatus = datagridComponent.defaultValue?.map((row, index) => ({
        rowIndex: index,
        product: row.product_name?.substring(0, 30) + "...",
        part_pk: row.part_pk,
        image: row.image === "unknown" ? "UNKNOWN" : "VALID",
        hasImage: row.image !== "unknown",
        allFields: Object.keys(row).filter(k => !k.includes('preview') && !k.includes('html'))
      }));
      
      console.log(`[handleRender] Datagrid mapping status:`, mappingStatus);
      console.log(`[handleRender] Images mapped successfully:`, mappingStatus?.filter(r => r.hasImage).length || 0);
      console.log(`[handleRender] Images still unknown:`, mappingStatus?.filter(r => !r.hasImage).length || 0);
      
      console.log(`[handleRender] Sample datagrid rows (first 2):`, JSON.stringify(datagridComponent.defaultValue?.slice(0, 2), null, 2));
    }

    console.log(`Setting up handlers (${Date.now() - startTime}ms)`);
    setupHandlers(schema, formState, onRenderDetails.api);

    const totalTime = Date.now() - startTime;
    console.log(`DynamicRender completed for ${process} in ${totalTime}ms`);
    
    console.log(`[handleRender] Final return object keys:`, Object.keys({
      schema,
      onRenderDetails,
      event: otherEvent,
    }));
    console.log(`[handleRender] Final schema component types:`, schema.components?.map(c => `${c.key}(${c.type})`));

    return {
      schema,
      onRenderDetails,
      event: otherEvent,
    };
  } catch (error) {
    console.error("Error in dynamicRender:", error);
    throw new Error(`Failed to configure process: ${error.message}`);
  }
}

module.exports = dynamicRender;
