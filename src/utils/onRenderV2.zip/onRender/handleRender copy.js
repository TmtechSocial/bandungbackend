const {
  configureProcess,
  configureQuery,
} = require("../../controller/controllerConfig");
const { getMember } = require("../ldap/ldapHierarki");
const axios = require("axios");

/**
 * Dynamic form rendering function that processes form schemas and populates them with data
 * from various sources including API calls, database queries, and session data
 *
 * @param {Object} fastify - Fastify instance
 * @param {String} process - Process identifier
 * @param {String|Array} instance - Process instance(s) identifier
 * @param {Object} session - User session data
 * @returns {Object} Rendered form schema with populated data
 */
async function dynamicRender(fastify, process, instance, session) {
  console.log("Session data:", session);
  try {
    // Get process schema based on whether it's a grid or single instance
    let schema;
    const getSchema = await configureProcess(fastify, process);
    schema = Array.isArray(instance)
      ? getSchema[0].schema_grid_json
      : getSchema[0].schema_json;

    // Get process event configurations
    const getEvent = await configureProcess(fastify, process);
    const { onRender: renderEvent, ...otherEvent } = getEvent[0].event_json;

    let onRenderDetails = renderEvent;

    // Update process variables if instance ID exists
    if (instance && (Array.isArray(instance) ? instance.length > 0 : true)) {
      const { graph, query } = renderEvent;

      if (graph && graph.variables) {
        const updatedGraph = {
          ...graph,
          variables: {
            ...(graph.variables || {}),
            proc_inst_id: instance,
          },
        };

        onRenderDetails = {
          ...renderEvent,
          graph: updatedGraph,
        };
      }
    }

    // Form state management
    let formState = {
      data: {},
      apiResults: {},
      dependencies: new Map(),
    };

    /**
     * Track component dependencies for dynamic updates
     */
    const setupComponentDependencies = () => {
      schema.components.forEach((component) => {
        const { key, apiSource, defaultValue } = component;

        // Isi default value ke formState.data (biar formState.data langsung lengkap)
        if (defaultValue !== undefined && defaultValue !== null) {
          formState.data[key] = defaultValue;
        }

        // Setup dependencies untuk component yang tergantung pada field lain
        if (apiSource && apiSource.dependsOn) {
          const dependsOn = apiSource.dependsOn;

          if (!formState.dependencies.has(dependsOn)) {
            formState.dependencies.set(dependsOn, []);
          }

          formState.dependencies.get(dependsOn).push(key);
        }
      });

      console.log(
        "Component dependencies established:",
        formState.dependencies
      );
      console.log("Initial formState.data:", formState.data);
    };

    /**
     * Enhanced API caller that supports dynamic parameters from form data
     *
     * @param {Object} apiConfig - API request configuration
     * @param {Object} additionalData - Additional data to use for parameter substitution
     * @returns {Object|null} - API response data or null if request fails
     */
    async function fetchApiData(apiConfig, additionalData = {}) {
      try {
        // Create a deep copy to avoid modifying the original config
        const config = JSON.parse(JSON.stringify(apiConfig));
        const {
          url,
          method = "GET",
          headers = {},
          params = {},
          data = {},
        } = config;

        // Combined data sources for template substitution
        const substitutionData = {
          ...session,
          ...formState.data,
          ...additionalData,
        };

        // Process URL template
        let processedUrl = url;
        if (typeof processedUrl === "string") {
          processedUrl = processedUrl.replace(/\${([^}]+)}/g, (match, key) => {
            return substitutionData[key] !== undefined
              ? substitutionData[key]
              : "";
          });
        }

        // Process query parameters
        const processedParams = {};
        Object.keys(params).forEach((paramKey) => {
          let paramValue = params[paramKey];
          if (typeof paramValue === "string") {
            paramValue = paramValue.replace(/\${([^}]+)}/g, (match, key) => {
              return substitutionData[key] !== undefined
                ? substitutionData[key]
                : "";
            });
          }
          processedParams[paramKey] = paramValue;
        });

        // Process request body
        let processedData = {};
        if (typeof data === "string") {
          // Handle string data
          processedData = data.replace(/\${([^}]+)}/g, (match, key) => {
            return substitutionData[key] !== undefined
              ? substitutionData[key]
              : "";
          });
        } else {
          // Handle object data
          Object.keys(data).forEach((dataKey) => {
            let dataValue = data[dataKey];
            if (typeof dataValue === "string") {
              dataValue = dataValue.replace(/\${([^}]+)}/g, (match, key) => {
                return substitutionData[key] !== undefined
                  ? substitutionData[key]
                  : "";
              });
            }
            processedData[dataKey] = dataValue;
          });
        }

        console.log(`Fetching API data from: ${processedUrl}`);
        console.log("With params:", processedParams);

        const response = await axios({
          url: processedUrl,
          method,
          headers,
          params: processedParams,
          data: processedData,
          timeout: 10000, // 10 seconds timeout
        });

        console.log(`API response status: ${response.status}`);
        return response.data;
      } catch (error) {
        console.error(`Error fetching API data: ${error.message}`);
        return null;
      }
    }

    /**
     * Updates fields that depend on a changed field
     *
     * @param {String} changedKey - Key of the changed field
     * @param {*} value - New value of the changed field
     */
    async function updateDependentFields(changedKey, value) {
      // Update form state
      formState.data[changedKey] = value;

      // Check if any fields depend on this changed field
      const dependentFieldKeys = formState.dependencies.get(changedKey) || [];
      if (dependentFieldKeys.length === 0) return;

      console.log(
        `Updating ${dependentFieldKeys.length} fields that depend on ${changedKey}`
      );

      // Find the component that changed to get its value for dependency
      const changedComponent = schema.components.find(
        (comp) => comp.key === changedKey
      );
      let dependencyValue = value;

      // For select components, ensure we're using the value based on valueKey
      if (
        changedComponent &&
        changedComponent.type === "select" &&
        changedComponent.apiSource
      ) {
        // We already have the selected value which is based on valueKey
        dependencyValue = value;
      }

      // For each dependent field, update its data
      for (const fieldKey of dependentFieldKeys) {
        const component = schema.components.find(
          (comp) => comp.key === fieldKey
        );
        if (!component || !component.apiSource) continue;

        const apiSourceKey = component.apiSource.source;
        const apiConfig = onRenderDetails.api[apiSourceKey];

        if (!apiConfig) continue;

        // Fetch updated data with the dependency value
        const result = await fetchApiData(apiConfig, {
          [changedKey]: dependencyValue,
        });
        if (result) {
          formState.apiResults[apiSourceKey] = result;

          // Update the component based on its type
          if (component.type === "select") {
            updateSelectComponent(component, result);
          } else if (component.type === "selectboxes") {
            updateSelectBoxesComponent(component, result);
          } else if (component.type === "content") {
            updateContentComponent(component, result);
          } else {
            updateDefaultComponent(component, result);
          }
        }
      }
    }

    /**
     * Adds onChange handlers to form components
     */
    function setupComponentEventHandlers() {
      console.log("Setting up component event handlers");
      schema.components.forEach(component => {
        console.log("Component key:", component.key);
    
        // Tambahkan event handler ke SEMUA field yang jadi sumber dependency
        if (Array.from(formState.dependencies.keys()).includes(component.key) || component.onChange) {
          console.log(`Adding onChange handler for field: ${component.key}`);
          
          component.onChange = async (event) => {
            console.log("onChange event triggered for:", component.key);
            const value = event.value || event.target?.value || '';
            console.log(`Field ${component.key} changed to: ${value}`);
    
            // Update field seperti biasa
            await updateDependentFields(component.key, value);
    
            // 🔥 Kalau ada refreshField, refresh field tersebut juga
            if (component.onChange && component.onChange.refreshField) {
              console.log(`Field ${component.key} triggered refresh for: ${component.onChange.refreshField}`);
              const refreshFieldKey = component.onChange.refreshField;
              console.log(`Refreshing field: ${refreshFieldKey} because ${component.key} changed`);
    
              const refreshComponent = schema.components.find(comp => comp.key === refreshFieldKey);
              if (refreshComponent && refreshComponent.apiSource) {
                const refreshApiKey = refreshComponent.apiSource.source;
                const refreshApiConfig = onRenderDetails.api[refreshApiKey];
                if (refreshApiConfig) {
                  const refreshResult = await fetchApiData(refreshApiConfig, { [component.key]: value });
                  if (refreshResult) {
                    formState.apiResults[refreshApiKey] = refreshResult;
                    console.log(`Fetched refreshed API data for '${refreshFieldKey}'`);
    
                    if (refreshComponent.type === 'select') {
                      updateSelectComponent(refreshComponent, refreshResult);
                    } else if (refreshComponent.type === 'selectboxes') {
                      updateSelectBoxesComponent(refreshComponent, refreshResult);
                    } else if (refreshComponent.type === 'content') {
                      updateContentComponent(refreshComponent, refreshResult);
                    } else {
                      updateDefaultComponent(refreshComponent, refreshResult);
                    }
                  }
                }
              }
            }
          };
        }
      });
    }
      

    /**
     * Process all API configurations from render event
     */
    async function loadInitialApiData() {
      if (!onRenderDetails.api) return;

      const apiConfigs = onRenderDetails.api;

      console.log("apiConfigs", apiConfigs);

      // Process each API endpoint defined in the config
      for (const [key, config] of Object.entries(apiConfigs)) {
        const isDependentApi = Object.values(schema.components).some(
          (comp) =>
            comp.apiSource &&
            comp.apiSource.source === key &&
            comp.apiSource.dependsOn
        );

        if (isDependentApi) {
          console.log(`Skipping dependent API: ${key}`);
          continue;
        }

        const result = await fetchApiData(config);
        console.log(`API result for '${key}':`, result);
        if (result) {
          formState.apiResults[key] = result;
          console.log(`Stored API result for '${key}'`);
        }
      }

      // After loading independent APIs, fetch dependent APIs if their dependency value already exists
      for (const [fieldKey, dependentKeys] of formState.dependencies) {
        console.log(`Processing dependent API for field: ${fieldKey}`);
        const fieldValue = formState.data[fieldKey];
        if (fieldValue) {
          for (const dependentFieldKey of dependentKeys) {
            const dependentComponent = schema.components.find(
              (comp) => comp.key === dependentFieldKey
            );
            if (dependentComponent && dependentComponent.apiSource) {
              const dependentApiSourceKey = dependentComponent.apiSource.source;
              const dependentApiConfig =
                onRenderDetails.api[dependentApiSourceKey];
              if (dependentApiConfig) {
                const dependentResult = await fetchApiData(dependentApiConfig, {
                  [fieldKey]: fieldValue,
                });

                console.log(`Dependent API result for '${dependentApiSourceKey}':`, dependentResult);
                if (dependentResult) {
                  formState.apiResults[dependentApiSourceKey] = dependentResult;
                  console.log(
                    `Fetched dependent API '${dependentApiSourceKey}' based on '${fieldKey}'`
                  );

                  // 🔥 Tambahan update component field di sini!
                  if (dependentComponent.type === "select") {
                    updateSelectComponent(dependentComponent, dependentResult);
                  } else if (dependentComponent.type === "selectboxes") {
                    updateSelectBoxesComponent(
                      dependentComponent,
                      dependentResult
                    );
                  } else if (dependentComponent.type === "content") {
                    updateContentComponent(dependentComponent, dependentResult);
                  } else {
                    updateDefaultComponent(dependentComponent, dependentResult);
                  }
                }
              }
            }
          }
        }
      }
    }

    // Execute database queries
    const responseQuery = await configureQuery(fastify, onRenderDetails);
    if (!responseQuery.data) {
      throw new Error("Failed to configure process");
    }

    // Get LDAP member data if needed
    const memberResult = await getMember(fastify, session);

    /**
     * Processes components and populates them with data from queries, API, and session
     *
     * @param {Array} components - Form components to process
     * @param {Array} queryData - Database query results
     */
    const processComponents = (components, queryData) => {
      // Special handling for datagrid components
      if (
        Array.isArray(components) &&
        components.length > 0 &&
        components[0].type === "datagrid"
      ) {
        processDataGridComponent(components[0], queryData);
        return;
      }

      // Process regular components
      schema.components.forEach((component) => {
        processComponent(component, queryData);
      });
    };

    /**
     * Processes a datagrid component and its subcomponents
     *
     * @param {Object} component - Datagrid component
     * @param {Array} queryData - Database query results
     */
    // 🟢 Bagian di dalam function processDataGridComponent (Replace bagian ini di handleRender.js)

const processDataGridComponent = (component, queryData) => {
  const { components } = component;
  let newDefaultValue = [];

  // Proses dari query SQL & Graph seperti biasa
  queryData.forEach((queryItem) => {
    processQueryDataForDataGrid(queryItem, components, newDefaultValue);
  });

  // 🔁 Tambahan: proses API langsung dari datagrid jika ada
  const datagridApiSource = component.apiSource || components[0].apiSource;
  if (datagridApiSource) {
    processApiDataForDataGrid(
      datagridApiSource,
      components,
      newDefaultValue,
      formState.apiResults
    );
  }

  component.defaultValue = newDefaultValue;
};


    /**
     * Processes database query results for a datagrid
     *
     * @param {Object} queryItem - Query result item
     * @param {Array} components - Datagrid subcomponents
     * @param {Array} newDefaultValue - Collection of row data for the grid
     */
    const processQueryDataForDataGrid = (
      queryItem,
      components,
      newDefaultValue
    ) => {
      components.forEach((subComponent) => {
        const table = subComponent.table;
        const defaultValue = subComponent.defaultValue;

        // Handle session variables in defaultValue
        if (
          typeof defaultValue === "string" &&
          defaultValue.includes("session")
        ) {
          const sessionKey = defaultValue.split(".")[1];
          if (sessionKey && session[sessionKey] !== undefined) {
            subComponent.defaultValue = session[sessionKey];
          }
        }

        // Process SQL query results
        if (queryItem.sqlQuery && queryItem.sqlQuery.table === table) {
          processDataGridRows(
            queryItem.sqlQuery.data,
            components,
            newDefaultValue
          );
        }

        // Process graph query results
        if (queryItem.graph && queryItem.graph[table]) {
          processDataGridRows(
            queryItem.graph[table],
            components,
            newDefaultValue
          );
        }
      });
    };

    /**
     * Processes API data for a datagrid
     *
     * @param {Object} apiSource - API source configuration
     * @param {Array} components - Datagrid subcomponents
     * @param {Array} newDefaultValue - Collection of row data for the grid
     * @param {Object} apiData - All API results
     */
    const processApiDataForDataGrid = (
      apiSource,
      components,
      newDefaultValue,
      apiData
    ) => {
      const sourceKey = apiSource.source;
      const dataPath = apiSource.dataPath || [];

      let apiItems = apiData[sourceKey];

      // Navigate to the correct data path if specified
      if (dataPath.length > 0) {
        for (const segment of dataPath) {
          if (apiItems && apiItems[segment]) {
            apiItems = apiItems[segment];
          } else {
            apiItems = null;
            break;
          }
        }
      }

      if (apiItems && Array.isArray(apiItems)) {
        processDataGridRows(apiItems, components, newDefaultValue);
      }
    };

    /**
     * Processes rows of data for a datagrid
     *
     * @param {Array} items - Row data items
     * @param {Array} components - Datagrid subcomponents
     * @param {Array} newDefaultValue - Collection of row data for the grid
     */
    const processDataGridRows = (items, components, newDefaultValue) => {
      items.forEach((item) => {
        let row = {};
        components.forEach((subComp) => {
          const key = subComp.key;
          if (item[key] !== undefined) {
            row[key] = item[key];
          }
        });

        // Check for duplicates
        const isDuplicate = newDefaultValue.some((existingRow) => {
          return Object.keys(row).every((key) => row[key] === existingRow[key]);
        });

        if (!isDuplicate && Object.keys(row).length > 0) {
          newDefaultValue.push(row);
        }
      });
    };

    /**
     * Processes a single form component
     *
     * @param {Object} component - Form component
     * @param {Array} queryData - Database query results
     */
    const processComponent = (component, queryData) => {
      const key = component.key;
      const table = component.table;
      const type = component.type;
      let value = component.defaultValue;

      // Process component based on its type
      switch (type) {
        case "select":
          processSelectComponent(component, table, key, value, queryData);
          break;
        case "selectboxes":
          processSelectBoxesComponent(component);
          break;
        case "content":
          processContentComponent(component, table, key, queryData);
          break;
        default:
          processDefaultComponent(component, table, key, value, queryData);
          break;
      }

      // Process session variables in string values
      processComponentSessionReferences(component);

      // Process API references in string values
      processComponentApiReferences(component);
    };

    /**
     * Updates a select component with API data
     *
     * @param {Object} component - Select component
     * @param {Object} apiData - API data
     */
    function updateSelectComponent(component, apiData) {
      const { apiSource } = component;
      if (!apiSource) return;

      const {
        labelKey = "label",
        valueKey = "value",
        optionsPath = [],
      } = apiSource;

      // Initialize or reset the values array
      component.data = component.data || { values: [] };
      component.data.values = [];

      // Extract options from API data
      let options = apiData;
      if (optionsPath && optionsPath.length > 0) {
        for (const path of optionsPath) {
          if (options && options[path]) {
            options = options[path];
          } else {
            options = null;
            break;
          }
        }
      }

      // Add options to the select component
      if (options && Array.isArray(options)) {
        options.forEach((option) => {
          component.data.values.push({
            label: String(option[labelKey] || "No Label"),
            value: String(option[valueKey] || ""),
          });
        });
      }
    }

    /**
     * Updates a selectboxes component with API data
     *
     * @param {Object} component - Selectboxes component
     * @param {Object} apiData - API data
     */
    function updateSelectBoxesComponent(component, apiData) {
      const { apiSource } = component;
      if (!apiSource) return;

      const {
        labelKey = "label",
        valueKey = "value",
        optionsPath = [],
      } = apiSource;

      // Initialize arrays and objects
      component.values = [];
      const defaultValue = {};

      // Extract options from API data
      let options = apiData;
      if (optionsPath && optionsPath.length > 0) {
        for (const path of optionsPath) {
          if (options && options[path]) {
            options = options[path];
          } else {
            options = null;
            break;
          }
        }
      }

      // Add options to the selectboxes component
      if (options && Array.isArray(options)) {
        options.forEach((option) => {
          const label = String(option[labelKey] || "No Label");
          const value = String(option[valueKey] || "");

          component.values.push({
            label,
            value,
            shortcut: "",
          });

          defaultValue[value] = false;
        });
      }

      component.defaultValue = defaultValue;
    }

    /**
     * Updates a content component with API data
     *
     * @param {Object} component - Content component
     * @param {Object} apiData - API data
     */
    function updateContentComponent(component, apiData) {
      const { apiSource } = component;
      if (!apiSource) return;

      const { contentPath = [], templateType = "links", template } = apiSource;

      // Extract content from API data
      let content = apiData;
      if (contentPath && contentPath.length > 0) {
        for (const path of contentPath) {
          if (content && content[path]) {
            content = content[path];
          } else {
            content = null;
            break;
          }
        }
      }

      let htmlContent = "";

      // Generate HTML based on content type
      if (content) {
        if (Array.isArray(content)) {
          if (templateType === "links") {
            const linkKey = apiSource.linkKey || "url";
            const textKey = apiSource.textKey || "title";

            htmlContent = content
              .map((item) => {
                return `<p><a style="display: inline-block;
background-color: #8f8f8f;
color: #ffffff;
padding: 8px 12px;
margin: 10px 0;
border-radius: 6px;
text-decoration: none;
font-weight: bold;
font-size: 14px;
transition: all 0.3s ease-in-out;
box-shadow: 0px 4px 6px rgba(0, 0, 0, 0.1);
margin-bottom: 3px;" href="${item[linkKey]}" target="_blank">${item[textKey]}</a></p>`;
              })
              .join("");
          } else if (templateType === "list") {
            const textKey = apiSource.textKey || "text";

            htmlContent = `<ul>${content
              .map((item) => `<li>${item[textKey]}</li>`)
              .join("")}</ul>`;
          } else if (templateType === "custom" && template) {
            htmlContent = content
              .map((item) => {
                let rendered = template;
                Object.keys(item).forEach((key) => {
                  const regex = new RegExp(`\\{\\{${key}\\}\\}`, "g");
                  rendered = rendered.replace(regex, item[key]);
                });
                return rendered;
              })
              .join("");
          }
        } else if (typeof content === "object") {
          // For single objects
          if (template) {
            let rendered = template;
            Object.keys(content).forEach((key) => {
              const regex = new RegExp(`\\{\\{${key}\\}\\}`, "g");
              rendered = rendered.replace(regex, content[key]);
            });
            htmlContent = rendered;
          } else {
            htmlContent = `<pre>${JSON.stringify(content, null, 2)}</pre>`;
          }
        } else {
          // For primitive values
          htmlContent = String(content);
        }
      }

      component.html = htmlContent;
    }

    /**
     * Updates a default component with API data
     *
     * @param {Object} component - Component
     * @param {Object} apiData - API data
     */
    function updateDefaultComponent(component, apiData) {
      const { apiSource } = component;
      if (!apiSource) return;

      const { valueKey, dataPath = [] } = apiSource;

      // Extract value from API data
      let value = apiData;
      if (dataPath && dataPath.length > 0) {
        for (const path of dataPath) {
          if (value && value[path]) {
            value = value[path];
          } else {
            value = null;
            break;
          }
        }
      }

      // Get specific value if valueKey is specified
      if (valueKey && value && value[valueKey] !== undefined) {
        value = value[valueKey];
      }

      // Update component value if data was found
      if (value !== null) {
        component.defaultValue = value;
      }
    }

    /**
     * Processes a select component
     *
     * @param {Object} component - Select component
     * @param {String} table - Associated table name
     * @param {String} key - Component key
     * @param {*} value - Default value
     * @param {Array} queryData - Database query results
     */
    const processSelectComponent = (
      component,
      table,
      key,
      value,
      queryData
    ) => {
      // Initialize values array for select options
      component.data = component.data || { values: [] };

      // Process database query results for select options
      queryData.forEach((queryItem) => {
        // SQL query data
        if (queryItem.sqlQuery && queryItem.sqlQuery.table === table) {
          queryItem.sqlQuery.data.forEach((result) => {
            if (result[`value_${table}`] !== undefined) {
              component.data.values.push({
                label: String(result[`label_${table}`] || "No Label"),
                value: String(result[`value_${table}`] || ""),
              });
            }
          });
        }

        // Graph query data
        if (queryItem.graph && queryItem.graph[table]) {
          const graphData = queryItem.graph[table];
          if (Array.isArray(graphData)) {
            graphData.forEach((graphItem) => {
              if (graphItem[key] !== undefined) {
                component.data.values.push({
                  label: String(graphItem.label || "No Label"),
                  value: String(graphItem[key] || ""),
                });
              }
            });
          }
        }
      });

      // Process API data for select options
      if (component.apiSource) {
        const sourceKey = component.apiSource.source;
        const apiData = formState.apiResults[sourceKey];

        if (apiData) {
          updateSelectComponent(component, apiData);
        }
      }

      // Set default value if needed
      if (component.data.values.length === 0 && value !== undefined) {
        component.defaultValue = value;
      }
    };

    /**
     * Processes a selectboxes component
     *
     * @param {Object} component - Selectboxes component
     */
    const processSelectBoxesComponent = (component) => {
      const values = [];
      const defaultValue = {};

      // Process LDAP member data for selectboxes
      memberResult.forEach((member) => {
        const cn = member.cn;
        const uid = member.uid;
        values.push({
          label: String(cn),
          value: String(uid),
          shortcut: "",
        });
        defaultValue[cn] = false;
        defaultValue[uid] = false;
      });

      // Process API data for selectboxes
      if (component.apiSource) {
        const sourceKey = component.apiSource.source;
        const apiData = formState.apiResults[sourceKey];

        if (apiData) {
          updateSelectBoxesComponent(component, apiData);
        }
      }

      // Update component with values and defaultValue if not already set by API
      if (!component.values || component.values.length === 0) {
        component.values = values;
        component.defaultValue = defaultValue;
      }
    };

    /**
     * Processes a content component
     *
     * @param {Object} component - Content component
     * @param {String} table - Associated table name
     * @param {String} key - Component key
     * @param {Array} queryData - Database query results
     */
    const processContentComponent = (component, table, key, queryData) => {
      let htmlContent = "";

      // Process database data for content
      queryData.forEach((queryItem) => {
        // SQL query data
        if (queryItem.sqlQuery && queryItem.sqlQuery.table === table) {
          const sqlQueryResults = queryItem.sqlQuery.data.filter(
            (item) => item[key] !== undefined
          );
          if (sqlQueryResults.length > 0) {
            htmlContent = sqlQueryResults
              .map((result, index) => {
                return `<p><a style="background-color: blue; text-color: white; padding: 5px; border-radius: 10px;" href="http://localhost:5000/get-image/${
                  result[key]
                }">Gambar ${index + 1}</a></p>`;
              })
              .join("");
          }
        }

        // Graph query data
        if (queryItem.graph && queryItem.graph[table]) {
          const graphData = queryItem.graph[table];
          if (Array.isArray(graphData)) {
            const graphItems = graphData.filter(
              (item) => item[key] !== undefined
            );
            if (graphItems.length > 0) {
              htmlContent = graphItems
                .map((item, index) => {
                  return `<p><a style="display: inline-block;
    background-color: #8f8f8f;
    color: #ffffff;
    padding: 8px 12px;
    margin: 10px 0;
    border-radius: 6px;
    text-decoration: none;
    font-weight: bold;
    font-size: 14px;
    transition: all 0.3s ease-in-out;
    box-shadow: 0px 4px 6px rgba(0, 0, 0, 0.1);
    margin-bottom: 3px;" href="http://localhost:5000/get-image/${
      item[key]
    } "  target="_blank">Document From ${item.proc_def_key.replace(
                    /_/g,
                    " "
                  )}</a></p>`;
                })
                .join("");
            }
          }
        }
      });

      // Process API data for content
      if (component.apiSource) {
        const sourceKey = component.apiSource.source;
        const apiData = formState.apiResults[sourceKey];

        if (apiData) {
          updateContentComponent(component, apiData);
        }
      }

      // Update component with HTML content
      component.html = htmlContent || component.html;
    };

    /**
     * Processes default components (not select, selectboxes, or content)
     *
     * @param {Object} component - Form component
     * @param {String} table - Associated table name
     * @param {String} key - Component key
     * @param {*} value - Default value
     * @param {Array} queryData - Database query results
     */
    const processDefaultComponent = (
      component,
      table,
      key,
      value,
      queryData
    ) => {
      // Process database query results
      queryData.forEach((queryItem) => {
        // SQL query data
        if (queryItem.sqlQuery && queryItem.sqlQuery.table === table) {
          const sqlQueryResult = queryItem.sqlQuery.data.find(
            (item) => item[key] !== undefined
          );
          if (sqlQueryResult) {
            value = sqlQueryResult[key];
          }
        }

        // Graph query data
        if (queryItem.graph && queryItem.graph[table]) {
          const graphData = queryItem.graph[table];
          if (Array.isArray(graphData)) {
            const graphItem = graphData.find((item) => item[key] !== undefined);
            if (graphItem) {
              value = graphItem[key];
            }
          }
        }
      });

      // Process API data
      if (component.apiSource) {
        const sourceKey = component.apiSource.source;
        const apiData = formState.apiResults[sourceKey];

        if (apiData) {
          updateDefaultComponent(component, apiData);
        }
      }

      // Update component default value
      component.defaultValue = value;
    };

    /**
     * Processes session variable references in component values
     *
     * @param {Object} component - Form component
     */
    const processComponentSessionReferences = (component) => {
      const defaultValue = component.defaultValue;

      if (
        typeof defaultValue === "string" &&
        defaultValue.includes("session")
      ) {
        const sessionKey = defaultValue.split(".")[1];
        if (sessionKey && session[sessionKey] !== undefined) {
          component.defaultValue = session[sessionKey];
        }
      }
    };

    /**
     * Processes API references in component values
     *
     * @param {Object} component - Form component
     */
    const processComponentApiReferences = (component) => {
      const value = component.defaultValue;

      if (typeof value === "string" && value.includes("api.")) {
        const matches = value.match(/api\.([^}\s]+)/);
        if (matches && matches[1]) {
          const apiPath = matches[1].split(".");
          let apiValue = formState.apiResults;

          // Navigate through the API response object
          for (const segment of apiPath) {
            if (apiValue && apiValue[segment] !== undefined) {
              apiValue = apiValue[segment];
            } else {
              apiValue = null;
              break;
            }
          }

          if (apiValue !== null) {
            component.defaultValue =
              typeof apiValue === "object"
                ? JSON.stringify(apiValue)
                : String(apiValue);
          }
        }
      }
    };

    // Set up dependencies between components
    setupComponentDependencies();

    // Load initial API data
    await loadInitialApiData();

    console.log("Initial API data loaded");
    // Set up event handlers
    setupComponentEventHandlers();

    // Process query data and flatten nested structures
    const queryData = responseQuery.data;
    const processedQueryData = processQueryData(queryData);

    // Process form components with data from all sources
    processComponents(schema.components, processedQueryData);

    return {
      schema,
      onRenderDetails: onRenderDetails,
      event: otherEvent,
    };
  } catch (error) {
    console.error("Error in dynamicRender:", error);
    throw new Error(`Failed to configure process: ${error.message}`);
  }
}

/**
 * Processes and flattens nested query data structures
 *
 * @param {Object|Array} data - Query data to process
 * @returns {Array} - Processed and flattened data
 */
function processQueryData(data) {
  // Function to process graph structure while maintaining its key
  const processGraphStructure = (item) => {
    const graph = {};

    if (item.graph) {
      for (const key in item.graph) {
        if (Array.isArray(item.graph[key])) {
          graph[key] = flattenArrayAndObjects(item.graph[key]);
        } else if (
          typeof item.graph[key] === "object" &&
          item.graph[key] !== null
        ) {
          graph[key] = flattenCompleteObject(item.graph[key]);
        } else {
          graph[key] = item.graph[key];
        }
      }
      return { ...item, graph };
    }

    // If no graph structure, flatten the entire object
    return flattenCompleteObject(item);
  };

  // Function to flatten arrays while maintaining array structure
  const flattenArrayAndObjects = (arr) => {
    return arr.reduce((flat, item) => {
      if (Array.isArray(item)) {
        return flat.concat(flattenArrayAndObjects(item));
      }

      if (typeof item === "object" && item !== null) {
        return flat.concat(flattenCompleteObject(item));
      }

      return flat.concat(item);
    }, []);
  };

  // Function to completely flatten an object to single level
  const flattenCompleteObject = (obj) => {
    const result = {};

    const flatten = (current) => {
      for (const key in current) {
        if (current[key] && typeof current[key] === "object") {
          if (Array.isArray(current[key])) {
            current[key].forEach((item) => {
              if (item && typeof item === "object") {
                flatten(item);
              }
            });
          } else {
            flatten(current[key]);
          }
        } else {
          result[key] = current[key];
        }
      }
    };

    flatten(obj);
    return result;
  };

  // Main processing logic
  if (Array.isArray(data)) {
    return data.map((item) => processGraphStructure(item));
  }
  return [processGraphStructure(data)];
}

module.exports = dynamicRender;
