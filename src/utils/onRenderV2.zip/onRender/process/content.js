function processContentComponent(component, queryData, formState, apiConfigs) {
  // Optimization: Remove excessive logging that slows down processing
  const sourceKey = component.apiSource?.source;
  const valueKey = component.apiSource?.valueKey;
  const apiKey = component.apiSource?.link;
  
  // If component has both apiSource and html template, process the template
  if (sourceKey && valueKey && component.html) {
    const apiData = formState.apiResults?.[sourceKey];
    let htmlContentArray = [];
    
    if (apiData) {
      const dataItems = Array.isArray(apiData) ? apiData : [apiData];
      
      dataItems.forEach((dataItem) => {
        if (Array.isArray(dataItem)) {
          dataItem.forEach((item) => {
            const imageUrl = item[valueKey];
            
            if (imageUrl) {
              const fullImageUrl = `${apiKey}${imageUrl}`;
              const processedHtml = component.html.replace(/\$\{[^}]+\}/g, fullImageUrl);
              htmlContentArray.push(processedHtml);
            } else {
              htmlContentArray.push(`
                <div style='text-align:center; padding: 20px; color: #888;'>
                  <span>No Image Available</span>
                </div>
              `);
            }
          });
        } else if (dataItem?.[valueKey]) {
          const imageUrl = dataItem[valueKey];
          const fullImageUrl = `${apiKey}${imageUrl}`;
          const processedHtml = component.html.replace(/\$\{[^}]+\}/g, fullImageUrl);
          htmlContentArray.push(processedHtml);
        } else {
          htmlContentArray.push(`
            <div style='text-align:center; padding: 20px; color: #888;'>
              <span>Image Not Found</span>
            </div>
          `);
        }
      });
    } else {
      htmlContentArray.push(`
        <div style='text-align:center; padding: 20px; color: #888; border: 1px dashed #ccc;'>
          <span>API Data Not Available</span>
        </div>
      `);
    }
    
    return htmlContentArray;
  }
  
  // Fallback to old logic if no apiSource or html template
  if (!sourceKey || !valueKey) {
    return [];
  }
  
  const apiData = formState.apiResults?.[sourceKey];
  let htmlContentArray = [];
  
  if (apiData) {
    const dataItems = Array.isArray(apiData) ? apiData : [apiData];
    
    dataItems.forEach((dataItem) => {
      if (Array.isArray(dataItem)) {
        dataItem.forEach((item) => {
          const imageUrl = item[valueKey];
          
          if (imageUrl) {
            const fullImageUrl = `${apiKey}${imageUrl}`;
            htmlContentArray.push(`
              <div style='text-align:center;'>
                <img src='${fullImageUrl}' alt='Image Content' style='max-width:100%; height:auto;'/>
              </div>
            `);
          } else {
            htmlContentArray.push(`
              <div style='text-align:center; padding: 20px; color: #888;'>
                <span>No Image Available</span>
              </div>
            `);
          }
        });
      } else if (dataItem?.[valueKey]) {
        const imageUrl = dataItem[valueKey];
        const fullImageUrl = `${apiKey}${imageUrl}`;
        htmlContentArray.push(`
          <div style='text-align:center;'>
            <img src='${fullImageUrl}' alt='Image Content' style='max-width:100%; height:auto;'/>
          </div>
        `);
      } else {
        htmlContentArray.push(`
          <div style='text-align:center; padding: 20px; color: #888;'>
            <span>Unknown Content</span>
          </div>
        `);
      }
    });
  } else {
    htmlContentArray.push(`
      <div style='text-align:center; padding: 20px; color: #888; border: 1px dashed #ccc;'>
        <span>API Data Not Available</span>
      </div>
    `);
  }
  
  return htmlContentArray;
}

module.exports = processContentComponent;

