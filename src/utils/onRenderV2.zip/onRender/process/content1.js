// process/content.js

function processContentComponent(component, queryData, formState, apiConfigs) {
    const { key, table } = component;
    let htmlContent = "";
  
    queryData.forEach((queryItem) => {
      if (queryItem.sqlQuery?.table === table) {
        queryItem.sqlQuery.data.forEach((result, index) => {
          if (result[key]) {
            htmlContent += `<p><a href="http://localhost:5000/get-image/${result[key]}" target="_blank">Gambar ${index + 1}</a></p>`;
          }
        });
      }
  
      if (queryItem.graph?.[table]) {
        queryItem.graph[table].forEach((item, index) => {
          if (item[key]) {
            htmlContent += `<p><a href="http://localhost:5000/get-image/${item[key]}" target="_blank">Document From ${item.proc_def_key?.replace(/_/g, " ")}</a></p>`;
          }
        });
      }
    });
  
    const sourceKey = component.apiSource?.source;
    const apiData = formState.apiResults[sourceKey];
    if (apiData) {
      component.html = htmlContent; // override if needed
    }
  
    if (!component.html) {
      component.html = htmlContent;
    }
  }
  
  module.exports = processContentComponent;
  