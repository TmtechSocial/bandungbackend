// process/default.js

function processDefaultComponent(component, queryData, formState, apiConfigs, session) {
    const { table, key, defaultValue } = component;
    let value = defaultValue;

    //console.log("Processing default component:", component);
    //console.log("Query data:", queryData);
  
    // Process data from SQL/Graph sources
    if(table) {
      queryData.forEach((queryItem) => {
        if (queryItem.sqlQuery?.table === table) {
          const found = queryItem.sqlQuery.data.find((item) => item[key] !== undefined);
          if (found) value = found[key];
        }
        if (queryItem.graph?.[table]) {
          const found = queryItem.graph[table].find((item) => item[key] !== undefined);
          if (found) value = found[key];
        }
      });
    }
  
    // Process API source data (now supporting arrays)
    if (component.apiSource) {
      //console.log("Processing component.apiSource:", component.apiSource);
      const sourceKey = component.apiSource.source;
      const apiData = formState.apiResults[sourceKey];
      //console.log("API Results for", sourceKey, ":", apiData);
      
      const { valueKey, dataPath = [] } = component.apiSource;
      
      if (apiData) {
        // Handle both array and single object responses
        const dataItems = Array.isArray(apiData) ? apiData : [apiData];
        
        if (dataItems.length > 0) {
          // Use the first item by default - this could be modified based on requirements
          let val = dataItems[0];
          
          // Navigate through the dataPath if defined
          for (const path of dataPath) {
            val = val?.[path] ?? null;
          }
          
          if (valueKey && val?.[valueKey] !== undefined) {
            //console.log(`Setting value from valueKey ${valueKey}:`, val[valueKey]);
            value = val[valueKey];
          } else if (val !== null) {
            //console.log("Setting value from direct val:", val);
            value = val;
          }
        }
      }
    }
  
    // Handle session reference
    if (typeof value === "string" && value.includes("session.")) {
      const key = value.split(".")[1];
      if (session?.[key] !== undefined) {
        value = session[key];
      }
    }
  
    component.defaultValue = value;
}
  
module.exports = processDefaultComponent;
