// process/processComponents.js - OPTIMIZED VERSION

const processSelectComponent = require("./select");
const processSelectBoxesComponent = require("./selectboxes");
const processContentComponent = require("./content");
const processDefaultComponent = require("./default");
const processDataGridComponent = require("./datagrid");
const processEditGridComponent = require("./editgrid");

// Optimization: Component processor mapping for faster lookup
const componentProcessors = {
  select: processSelectComponent,
  selectboxes: processSelectBoxesComponent,
  content: processContentComponent,
  datagrid: processDataGridComponent,
  editgrid: processEditGridComponent,
  default: processDefaultComponent,
};

async function processComponents(
  components,
  queryData,
  formState,
  session,
  apiConfigs,
  memberResult
) {
  const startTime = Date.now();
  console.log("Starting processComponents...");

  // Pastikan data API/GraphQL sudah tersedia sebelum mapping
  if (formState && formState.apiResults) {
    console.log(
      "[processComponents] API Results available keys:",
      Object.keys(formState.apiResults)
    );
  } else {
    console.warn("[processComponents] API Results belum tersedia!");
  }

  // Optimization: Normalize components to array
  if (
    components &&
    typeof components === "object" &&
    !Array.isArray(components)
  ) {
    components = [components];
  }

  if (!components || components.length === 0) {
    console.log("No components to process");
    return;
  }

  // Optimization: Group components by processing strategy
  const parallelComponents = [];
  const sequentialComponents = [];
  const fastSyncComponents = [];

  components.forEach((component) => {
    const { type } = component;

    // Fast sync components (no async operations, lightweight)
    if (type === "default") {
      fastSyncComponents.push(component);
    }
    // Heavy components that can run in parallel (image processing, etc.)
    else if (type === "content") {
      parallelComponents.push(component);
    }
    // Components that might need API calls or have dependencies
    else {
      sequentialComponents.push(component);
    }
  });

  console.log(
    `Processing ${fastSyncComponents.length} fast sync, ${parallelComponents.length} parallel, ${sequentialComponents.length} sequential components`
  );

  // Process fast sync components first (no await needed)
  const syncStartTime = Date.now();
  fastSyncComponents.forEach((component) => {
    const processor = componentProcessors.default;
    try {
      processor(component, queryData, formState, apiConfigs, session);
    } catch (error) {
      console.error(
        `Error processing default component ${component.key}:`,
        error
      );
    }
  });
  const syncTime = Date.now() - syncStartTime;
  if (fastSyncComponents.length > 0) {
    console.log(`Fast sync components processed in ${syncTime}ms`);
  }

  // Process parallel components
  let parallelTime = 0;
  if (parallelComponents.length > 0) {
    const parallelStartTime = Date.now();
    const parallelPromises = parallelComponents.map(async (component) => {
      const { type } = component;
      const processor =
        componentProcessors[type] || componentProcessors.default;

      try {
        if (type === "content") {
          const htmlContentArray = processor(
            component,
            queryData,
            formState,
            apiConfigs
          );
          // Update the component's html property with the processed content
          if (htmlContentArray && htmlContentArray.length > 0) {
            component.html =
              htmlContentArray.length === 1
                ? htmlContentArray[0]
                : htmlContentArray.join("");
          }
        } else if (type === "selectboxes") {
          processor(component, formState, apiConfigs, memberResult);
        } else {
          processor(component, queryData, formState, apiConfigs, session);
        }
        return { success: true, type, key: component.key };
      } catch (error) {
        console.error(
          `Error processing ${type} component ${component.key}:`,
          error
        );
        return {
          success: false,
          type,
          key: component.key,
          error: error.message,
        };
      }
    });

    // FIXED: Properly await parallel components
    try {
      const results = await Promise.all(parallelPromises);
      const successful = results.filter((r) => r.success).length;
      parallelTime = Date.now() - parallelStartTime;
      console.log(
        `[processComponents] Parallel components completed in ${parallelTime}ms: ${successful}/${results.length} successful`
      );
      
      // Log details of parallel processing
      results.forEach(result => {
        if (result.success) {
          console.log(`[processComponents] Parallel ${result.type} [${result.key}]: SUCCESS`);
        } else {
          console.log(`[processComponents] Parallel ${result.type} [${result.key}]: FAILED - ${result.error}`);
        }
      });
    } catch (error) {
      parallelTime = Date.now() - parallelStartTime;
      console.error(
        `Error in parallel component processing (${parallelTime}ms):`,
        error
      );
    }
  }

  // Process sequential components
  const sequentialStartTime = Date.now();
  for (const component of sequentialComponents) {
    const { type } = component;
    const processor = componentProcessors[type] || componentProcessors.default;
    // Reset all possible cache/data for non-datagrid components
    if (type !== "datagrid") {
      // --- FIX: Only reset select if it has table or apiSource ---
      if (type === "select") {
        if (component.table || component.apiSource) {
          if (component.data && Array.isArray(component.data.values)) {
            component.data.values = [];
          }
        }
        // else: do not touch static select
      } else {
        if (component.data) {
          Object.keys(component.data).forEach((k) => delete component.data[k]);
        }
        if (typeof component.html !== "undefined") {
          component.html = undefined;
        }
        if (component.value) {
          component.value = undefined;
        }
      }
    }
    try {
      switch (type) {
        case "select":
          processor(component, queryData, formState, apiConfigs);
          break;
        case "datagrid":
          processor(component, queryData, formState);
          break;
        case "editgrid":
          processor(component, queryData, formState);
          break;
        case "selectboxes":
          processor(component, formState, apiConfigs, memberResult);
          break;
        default:
          processor(component, queryData, formState, apiConfigs, session);
          break;
      }
    } catch (error) {
      console.error(
        `Error processing ${type} component ${component.key}:`,
        error
      );
    }
  }
  const sequentialTime = Date.now() - sequentialStartTime;
  if (sequentialComponents.length > 0) {
    console.log(`[processComponents] Sequential components processed in ${sequentialTime}ms`);
    
    // Log details of what was processed sequentially
    const componentSummary = sequentialComponents.map(comp => `${comp.key}(${comp.type})`);
    console.log(`[processComponents] Sequential components:`, componentSummary);
  }

  const totalTime = Date.now() - startTime;
  console.log(
    `[processComponents] Completed in ${totalTime}ms (sync: ${syncTime}ms, parallel: ${parallelTime}ms, sequential: ${sequentialTime}ms)`
  );
  
  // Final summary
  const allComponents = [...fastSyncComponents, ...parallelComponents, ...sequentialComponents];
  const totalProcessed = allComponents.length;
  console.log(`[processComponents] Total components processed: ${totalProcessed}`);
  
  // Check for any datagrid specific results
  const datagridComponents = allComponents.filter(c => c.type === 'datagrid');
  if (datagridComponents.length > 0) {
    console.log(`[processComponents] Processed ${datagridComponents.length} datagrid component(s)`);
    datagridComponents.forEach(dg => {
      const rowCount = dg.defaultValue?.length || 0;
      console.log(`[processComponents] Datagrid [${dg.key}]: ${rowCount} rows generated`);
    });
  }
}

module.exports = processComponents;

