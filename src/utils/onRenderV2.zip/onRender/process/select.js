// process/select.js

function processSelectComponent(component, queryData, formState, apiConfigs) {
    if (formState && formState.apiResults) {
        console.log("[select] API Results available keys:", Object.keys(formState.apiResults));
    } else {
        console.warn("[select] API Results belum tersedia!");
    }
    
    const { table, key, defaultValue } = component;
    // Hanya reset data.values jika memang akan diisi ulang dari sumber data
    if (!component.data) {
        component.data = { values: [] };
    } else if (table || component.apiSource) {
        // Hanya clear jika memang akan diisi ulang dari SQL/Graph/API
        component.data.values = [];
    }

    // Process data from SQL/Graph sources
    if(table){
        queryData.forEach((queryItem) => {
            //console.log("Processing query data");
          if (queryItem.sqlQuery?.table === table) {
            queryItem.sqlQuery.data.forEach((result) => {
              component.data.values.push({
                label: String(result[`label_${table}`] || "No Label"),
                value: String(result[`value_${table}`] || ""),
              });
            });
          }
      
          if (queryItem.graph?.[table]) {
            console.log("Processing graph data");
            const labelKey = component.graphConfig?.labelKey || "label";
            const valueKey = component.graphConfig?.valueKey || key;
            //console.log("labelKey:", labelKey);
            //console.log("valueKey:", valueKey);

            //console.log("queryItem.graph[table]:", queryItem.graph[table]);
            queryItem.graph[table].forEach((graphItem) => {
              //console.log("graphItem:", graphItem);
                component.data.values.push({
                  label: String(graphItem[labelKey] || "No Label"),
                  value: String(graphItem[valueKey] || ""),
                });
            });
          }
        });
    }

    //console.log("Component API source:", component.apiSource);
  
    // Process API source data (now supporting arrays)
    if (component.apiSource) {
      const sourceKey = component.apiSource?.source;
      const apiData = formState.apiResults[sourceKey];
      console.log("API Results for", sourceKey, ":", apiData);
      
      if (apiData) {
        console.log("Processing API data source");
  
        const {
          labelKey = "label",
          valueKey = "value",
          optionsPath = []
        } = component.apiSource;
  
        // Handle both array and single object responses
        const dataItems = Array.isArray(apiData) ? apiData : [apiData];
        
        // Process each data item
        dataItems.forEach(dataItem => {
          let options = dataItem;
          
          // Navigate through the optionsPath if defined
          for (const path of optionsPath) {
            options = options?.[path] ?? null;
          }
          
          if (Array.isArray(options)) {
            // Process array of options
            options.forEach((opt) => {
              let label = "";
  
              // Support labelKey format like "location_name - quantity"
              if (labelKey.includes("-")) {
                label = labelKey.split("-").map(k => {
                  const cleanKey = k.trim();
                  return String(opt[cleanKey] ?? "");
                }).join(" - ");
              } else {
                label = String(opt[labelKey] ?? "No Label");
              }
  
              const value = String(opt[valueKey] ?? "");
              //console.log("Adding option:", { label, value });
              component.data.values.push({ label, value });
            });
          } else if (options && typeof options === 'object') {
            // Handle single object option
            let label = "";
            
            if (labelKey.includes("-")) {
              label = labelKey.split("-").map(k => {
                const cleanKey = k.trim();
                return String(options[cleanKey] ?? "");
              }).join(" - ");
            } else {
              label = String(options[labelKey] ?? "No Label");
            }
  
            const value = String(options[valueKey] ?? "");
            //console.log("Adding single option:", { label, value });
            component.data.values.push({ label, value });
          }
        });
      }
    }
    
    // Set default value if needed
    if (!component.defaultValue && defaultValue) {
      component.defaultValue = defaultValue;
    }
}
  
module.exports = processSelectComponent;
