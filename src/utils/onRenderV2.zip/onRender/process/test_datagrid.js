// Test file untuk menguji fungsi processDataGridComponent
const processDataGridComponent = require('./datagrid');

// Test case 1: Data query normal dengan beberapa API kosong
function testCase1() {
    console.log('\n=== TEST CASE 1: Query data dengan API partial ===');
    
    const component = {
        components: [
            { key: 'image', type: 'textfield', apiSource: { source: 'imageFromPk', valueKey: 'image' } },
            { key: 'product_name', type: 'textarea', table: 'mo_order_shop' },
            { key: 'sku_toko', type: 'textfield', table: 'mo_order_shop' },
            { key: 'image_preview', type: 'content', html: '<img src="test">' }
        ]
    };

    const queryData = [
        {
            graph: {
                mo_order_shop: [
                    { product_name: 'Product 1', sku_toko: 'SKU1' },
                    { product_name: 'Product 2', sku_toko: 'SKU2' },
                    { product_name: 'Product 3', sku_toko: 'SKU3' }
                ]
            }
        }
    ];

    const formState = {
        apiResults: {
            imageFromPk: [
                { image: '/path/to/image1.jpg' },
                null, // API kosong untuk row ke-2
                { image: '/path/to/image3.jpg' }
            ]
        }
    };

    processDataGridComponent(component, queryData, formState);
    
    console.log('Result:', component.defaultValue.map(row => ({
        product_name: row.product_name,
        image: row.image
    })));
}

// Test case 2: API completely empty
function testCase2() {
    console.log('\n=== TEST CASE 2: API Results kosong ===');
    
    const component = {
        components: [
            { key: 'image', type: 'textfield', apiSource: { source: 'imageFromPk', valueKey: 'image' } },
            { key: 'product_name', type: 'textarea', table: 'mo_order_shop' }
        ]
    };

    const queryData = [
        {
            graph: {
                mo_order_shop: [
                    { product_name: 'Product 1' },
                    { product_name: 'Product 2' }
                ]
            }
        }
    ];

    const formState = {
        apiResults: {
            imageFromPk: [] // Array kosong
        }
    };

    processDataGridComponent(component, queryData, formState);
    
    console.log('Result:', component.defaultValue.map(row => ({
        product_name: row.product_name,
        image: row.image
    })));
}

// Test case 3: No query data, using defaultValue
function testCase3() {
    console.log('\n=== TEST CASE 3: Menggunakan defaultValue existing ===');
    
    const component = {
        defaultValue: [
            { product_name: 'Existing Product', image: '/existing/image.jpg' },
            { product_name: 'Product No Image', image: null },
            { product_name: 'Product Empty Image', image: '' }
        ],
        components: [
            { key: 'image', type: 'textfield' },
            { key: 'product_name', type: 'textarea' }
        ]
    };

    const queryData = null;
    const formState = {};

    processDataGridComponent(component, queryData, formState);
    
    console.log('Result:', component.defaultValue.map(row => ({
        product_name: row.product_name,
        image: row.image
    })));
}

// Test case 4: Completely empty (no data)
function testCase4() {
    console.log('\n=== TEST CASE 4: Tidak ada data sama sekali ===');
    
    const component = {
        components: [
            { key: 'image', type: 'textfield' },
            { key: 'product_name', type: 'textarea' }
        ]
    };

    const queryData = null;
    const formState = {};

    processDataGridComponent(component, queryData, formState);
    
    console.log('Result:', component.defaultValue.map(row => ({
        product_name: row.product_name,
        image: row.image
    })));
}

// Jalankan semua test case
console.log('Starting DataGrid Tests...');
testCase1();
testCase2();
testCase3();
testCase4();
console.log('\nTests completed!');
