// process/selectboxes.js

function processSelectBoxesComponent(component, formState, apiConfigs, memberResult = []) {
    const values = [];
    const defaultValue = {};
  
    // Process member results if available
    memberResult.forEach((member) => {
      const cn = member.cn;
      const uid = member.uid;
      values.push({ label: String(cn), value: String(uid), shortcut: "" });
      defaultValue[cn] = false;
      defaultValue[uid] = false;
    });
  
    // Process API source data (now supporting arrays)
    if (component.apiSource) {
      const sourceKey = component.apiSource.source;
      const apiData = formState.apiResults[sourceKey];
      console.log("API Results for selectboxes:", apiData);
      
      const { labelKey = "label", valueKey = "value", optionsPath = [] } = component.apiSource;
      
      if (apiData) {
        // Handle both array and single object responses
        const dataItems = Array.isArray(apiData) ? apiData : [apiData];
        
        // Process each data item
        dataItems.forEach(dataItem => {
          let options = dataItem;
          
          // Navigate through the optionsPath if defined
          for (const path of optionsPath) {
            options = options?.[path] ?? null;
          }
          
          if (Array.isArray(options)) {
            // Process array of options
            options.forEach((opt) => {
              const label = String(opt[labelKey] || "No Label");
              const value = String(opt[valueKey] || "");
              values.push({ label, value, shortcut: "" });
              defaultValue[value] = false;
            });
          } else if (options && typeof options === 'object') {
            // Handle single object option
            const label = String(options[labelKey] || "No Label");
            const value = String(options[valueKey] || "");
            values.push({ label, value, shortcut: "" });
            defaultValue[value] = false;
          }
        });
      }
    }
  
    if (!component.values || component.values.length === 0) {
      component.values = values;
      component.defaultValue = defaultValue;
    }
}
  
module.exports = processSelectBoxesComponent;