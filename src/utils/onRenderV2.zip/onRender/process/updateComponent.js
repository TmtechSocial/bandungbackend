// process/updateComponent.js

function updateComponent(component, apiData) {
  //console.log("updateComponent received apiData:", apiData);
  
  const type = component.type;

  // Handle both single objects and arrays of objects
  // If apiData is already an array, use it as is
  // If it's a single object (not an array), wrap it in an array
  const dataArray = Array.isArray(apiData) ? apiData : [apiData];
  
  //console.log(`Processing component type: ${type} with ${dataArray.length} data items`);
  
  switch (type) {
    case "select":
      return updateSelect(component, dataArray);
    case "selectboxes":
      return updateSelectBoxes(component, dataArray);
    case "content":
      return updateContent(component, dataArray);
    case "editgrid":
      return updateEditGrid(component, dataArray);
    default:
      return updateDefault(component, dataArray);
  }
}
  
function updateSelect(component, apiData) {
  const { apiSource } = component;
  const { labelKey = "label", valueKey = "value", optionsPath = [] } = apiSource || {};

  // Hanya reset jika memang ada apiData yang valid
  if (apiData && apiData.length > 0) {
    component.data = { values: [] };
  } else if (!component.data) {
    component.data = { values: [] };
  }
  
  // Process each item in the apiData array
  apiData.forEach(dataItem => {
    let options = dataItem;
    
    // Navigate through the dataPath if defined
    for (const path of optionsPath) {
      options = options?.[path] ?? null;
    }
    
    // If options is an array, process each option
    if (Array.isArray(options)) {
      options.forEach(item => {
        let label = "";

        // Support labelKey format like "location_name - quantity"
        if (labelKey.includes("-")) {
          label = labelKey.split("-").map(k => {
            const cleanKey = k.trim();
            return String(item[cleanKey] ?? "");
          }).join(" - ");
        } else {
          label = String(item[labelKey] ?? "No Label");
        }

        const value = String(item[valueKey] ?? "");
        component.data.values.push({ label, value });
      });
    } else if (options && typeof options === 'object') {
      // Handle single object option
      let label = "";
      
      if (labelKey.includes("-")) {
        label = labelKey.split("-").map(k => {
          const cleanKey = k.trim();
          return String(options[cleanKey] ?? "");
        }).join(" - ");
      } else {
        label = String(options[labelKey] ?? "No Label");
      }

      const value = String(options[valueKey] ?? "");
      component.data.values.push({ label, value });
    }
  });
}
  
function updateSelectBoxes(component, apiData) {
  const { apiSource } = component;
  const { labelKey = "label", valueKey = "value", optionsPath = [] } = apiSource;

  component.values = [];
  const defaultValue = {};

  // Process each item in the apiData array
  apiData.forEach(dataItem => {
    let options = dataItem;
    
    // Navigate through the dataPath if defined
    for (const path of optionsPath) {
      options = options?.[path] ?? null;
    }
    
    // If options is an array, process each option
    if (Array.isArray(options)) {
      options.forEach(item => {
        const label = String(item[labelKey] || "No Label");
        const value = String(item[valueKey] || "");
        defaultValue[value] = false;
        component.values.push({ label, value, shortcut: "" });
      });
    } else if (options && typeof options === 'object') {
      // Handle single object option
      const label = String(options[labelKey] || "No Label");
      const value = String(options[valueKey] || "");
      defaultValue[value] = false;
      component.values.push({ label, value, shortcut: "" });
    }
  });
  
  component.defaultValue = defaultValue;
}
  
function updateContent(component, apiData) {
  const { apiSource } = component;
  const { contentPath = [], templateType = "links", template, linkKey = "url", textKey = "title" } = apiSource;

  let htmlContent = "";
  
  // Process each item in the apiData array
  apiData.forEach(dataItem => {
    let content = dataItem;
    
    // Navigate through the contentPath if defined
    for (const path of contentPath) {
      content = content?.[path] ?? null;
    }
    
    if (!content) return;
    
    if (Array.isArray(content)) {
      if (templateType === "links") {
        htmlContent += content
          .map((item) => `<p><a href="${item[linkKey]}" target="_blank">${item[textKey]}</a></p>`)
          .join("");
      } else if (templateType === "list") {
        htmlContent += `<ul>${content.map((item) => `<li>${item[textKey]}</li>`).join("")}</ul>`;
      } else if (templateType === "custom" && template) {
        htmlContent += content
          .map((item) => {
            let result = template;
            Object.keys(item).forEach((key) => {
              result = result.replace(new RegExp(`{{${key}}}`, "g"), item[key]);
            });
            return result;
          })
          .join("");
      }
    } else if (typeof content === "object") {
      htmlContent += template
        ? Object.entries(content).reduce((acc, [k, v]) => acc.replace(new RegExp(`{{${k}}}`, "g"), v), template)
        : `<pre>${JSON.stringify(content, null, 2)}</pre>`;
    } else {
      htmlContent += String(content);
    }
  });
  
  component.html = htmlContent;
}

function updateEditGrid(component, apiData) {
  //console.log("updateEditGrid with data:", apiData);
  
  const { components: subComponents } = component;
  const newDefaultValue = [];
  
  // Group sub-components by API source
  const apiComponentMap = {};
  subComponents.forEach((sc) => {
    if (sc.apiSource) {
      const source = sc.apiSource.source;
      if (!apiComponentMap[source]) {
        apiComponentMap[source] = [];
      }
      apiComponentMap[source].push(sc);
    }
  });
  
  // Process API data for EditGrid rows
  apiData.forEach(dataItem => {
    Object.entries(apiComponentMap).forEach(([source, apiComponents]) => {
      const dataPath = apiComponents[0]?.apiSource?.dataPath || [];
      let items = dataItem;
      
      // Navigate through the dataPath if defined
      for (const path of dataPath) {
        items = items?.[path] ?? null;
      }
      
      if (Array.isArray(items)) {
        items.forEach((item, index) => {
          // Create or update row
          let row = newDefaultValue[index] || {};
          
          apiComponents.forEach((sc) => {
            const valueKey = sc.apiSource.valueKey || sc.key;
            // Perubahan utama: isi 'unknown' jika value tidak ada
            if (item[valueKey] !== undefined && item[valueKey] !== null) {
              row[sc.key] = item[valueKey];
            } else {
              row[sc.key] = "unknown";
            }
          });
          
          // Update existing row or add new row
          if (newDefaultValue[index]) {
            newDefaultValue[index] = { ...newDefaultValue[index], ...row };
          } else {
            newDefaultValue.push(row);
          }
        });
      } else if (items && typeof items === 'object') {
        // Handle single object
        let row = newDefaultValue[0] || {};
        
        apiComponents.forEach((sc) => {
          const valueKey = sc.apiSource.valueKey || sc.key;
          if (items[valueKey] !== undefined && items[valueKey] !== null) {
            row[sc.key] = items[valueKey];
          } else {
            row[sc.key] = "unknown";
          }
        });
        
        if (newDefaultValue[0]) {
          newDefaultValue[0] = { ...newDefaultValue[0], ...row };
        } else {
          newDefaultValue.push(row);
        }
      }
    });
  });
  
  // Update the component's defaultValue
  if (newDefaultValue.length > 0) {
    component.defaultValue = newDefaultValue;
  }
  
  //console.log("Updated EditGrid defaultValue:", component.defaultValue);
}
  
function updateDefault(component, apiData) {
  //console.log("updateDefault with data:", apiData);
  const { valueKey, dataPath = [] } = component.apiSource || {};
  
  // Special handling for array data
  if (Array.isArray(apiData) && apiData.length > 0) {
    // Use the first item by default - this can be modified depending on requirements
    let value = apiData[0];
    
    // Navigate through the dataPath if defined
    for (const path of dataPath) {
      value = value?.[path] ?? null;
    }
    
    if (valueKey && value?.[valueKey] !== undefined) {
      //console.log(`Setting defaultValue from valueKey ${valueKey}:`, value[valueKey]);
      component.defaultValue = value[valueKey];
    } else if (value !== null) {
      //console.log("Setting defaultValue from direct value:", value);
      component.defaultValue = typeof value === "object" ? JSON.stringify(value) : String(value);
    }
  } else {
    //console.log("No valid API data found for default component");
  }
}
  
module.exports = updateComponent;
