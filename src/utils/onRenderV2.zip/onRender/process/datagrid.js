const processContentComponent = require('./content');

function processDataGridComponent(component, queryData, formState) {
    const { components } = component;
    const newDefaultValue = [];

    // Validasi data API/GraphQL
    if (formState && formState.apiResults) {
        console.log("[datagrid] API Results available keys:", Object.keys(formState.apiResults));
    } else {
        console.warn("[datagrid] API Results belum tersedia!");
    }

    // Proses content component terlebih dahulu, simpan hasil HTML berdasarkan key
    const contentHTMLMap = {};
    components.forEach((subComponent) => {
        if (subComponent.type === 'content') {
            // console.log(`Processing content component inside DataGrid: ${subComponent.key}`);
            processContentComponent(subComponent, queryData, formState);
            if (subComponent.html) {
                contentHTMLMap[subComponent.key] = subComponent.html;
            }
        }
    });

    // Identifikasi komponen utama (yang memiliki table dan bukan apiSource saja)
    const mainComponents = components.filter(sc => 
        sc.table && 
        sc.type !== 'content' && 
        !sc.apiSource && 
        ['textfield', 'textarea', 'number'].includes(sc.type)
    );

    //console.log("Main components (table-based, non-API):", mainComponents.map(c => c.key));

    // Buat mapping komponen berdasarkan nama table
    const tableComponentMap = {};
    components.forEach((subComponent) => {
        if (subComponent.type === 'content') return; // Sudah diproses
        const table = subComponent.table;
        if (!table) return;
        if (!tableComponentMap[table]) {
            tableComponentMap[table] = [];
        }
        tableComponentMap[table].push(subComponent);
    });

    // Proses data dari query (SQL/Graph)
    if (queryData) {
        // console.log("Query data found:", JSON.stringify(queryData, null, 2));

        queryData.forEach((queryItem) => {
            Object.entries(tableComponentMap).forEach(([table, tableComponents]) => {
                // console.log("Processing table:", table);

                // SQL
                if (queryItem.sqlQuery?.table === table) {
                    console.log(`[datagrid] Processing SQL data for table: ${table}, rows: ${queryItem.sqlQuery.data.length}`);
                    queryItem.sqlQuery.data.forEach((item, index) => {
                        const row = {};
                        
                        // STEP 1: Simpan SEMUA field dari query data (dinamis)
                        Object.keys(item).forEach(key => {
                            row[key] = item[key];
                        });
                        
                        // STEP 2: Override dengan component-specific logic
                        components.forEach((sc) => {
                            if (sc.key === "image") {
                                // Set default "unknown" untuk field image sejak awal
                                row[sc.key] = "unknown";
                            } else if (row[sc.key] === undefined) {
                                // Jika component key tidak ada di query data, biarkan undefined
                                row[sc.key] = undefined;
                            }
                            // Jika sudah ada dari query data, biarkan apa adanya
                        });
                        
                        // STEP 3: Tambahkan content HTML yang sudah diproses
                        Object.entries(contentHTMLMap).forEach(([key, html]) => {
                            row[key] = html;
                        });
                        
                        console.log(`[datagrid] SQL Row ${index}: ${item.product_name?.substring(0, 40)}..., fields saved:`, Object.keys(row).filter(k => k !== 'image_preview'));
                        newDefaultValue.push(row);
                    });
                }

                // Graph
                if (queryItem.graph?.[table]) {
                    console.log(`[datagrid] Processing graph data for table: ${table}, rows: ${queryItem.graph[table].length}`);
                    queryItem.graph[table].forEach((item, index) => {
                        const row = {};
                        
                        // STEP 1: Simpan SEMUA field dari query data (dinamis)
                        Object.keys(item).forEach(key => {
                            row[key] = item[key];
                        });
                        
                        // STEP 2: Override dengan component-specific logic
                        components.forEach((sc) => {
                            if (sc.key === "image") {
                                // Set default "unknown" untuk field image sejak awal
                                row[sc.key] = "unknown";
                            } else if (row[sc.key] === undefined) {
                                // Jika component key tidak ada di query data, biarkan undefined
                                row[sc.key] = undefined;
                            }
                            // Jika sudah ada dari query data, biarkan apa adanya
                        });
                        
                        // STEP 3: Tambahkan content HTML yang sudah diproses
                        Object.entries(contentHTMLMap).forEach(([key, html]) => {
                            row[key] = html;
                        });
                        
                        console.log(`[datagrid] Graph Row ${index}: ${item.product_name?.substring(0, 40)}..., fields saved:`, Object.keys(row).filter(k => k !== 'image_preview'));
                        newDefaultValue.push(row);
                    });
                }
            });
        });
    }

    // Proses data dari API hanya jika diperlukan untuk melengkapi data
    const apiComponentMap = {};
    components.forEach((sc) => {
        if (sc.type === 'content' || !sc.apiSource) return;
        const source = sc.apiSource.source;
        if (!apiComponentMap[source]) {
            apiComponentMap[source] = [];
        }
        apiComponentMap[source].push(sc);
    });

    // Proses data dari API hanya untuk update field image (dan field lain yang diperlukan)
    if (Object.keys(apiComponentMap).length > 0 && newDefaultValue.length > 0) {
        console.log(`[datagrid] Query rows: ${newDefaultValue.length}, API data available: ${Object.keys(formState.apiResults || {}).length}`);
        
        Object.entries(apiComponentMap).forEach(([source, apiComponents]) => {
            const apiItems = formState.apiResults?.[source];
            const dataPath = apiComponents[0]?.apiSource?.dataPath || [];
            let items = apiItems;

            // Traverse dataPath untuk mendapatkan array data yang benar
            for (const path of dataPath) {
                items = items?.[path] ?? null;
            }

            // Validasi apakah data API valid (array dengan elemen)
            const isValidApiData = items && Array.isArray(items) && items.length > 0;
            console.log(`[datagrid] API source [${source}]: ${isValidApiData ? `Array(${items.length})` : 'Invalid/Empty'}`);
            
            if (isValidApiData) {
                console.log(`[datagrid] Mapping ${newDefaultValue.length} rows with ${items.length} API items`);
                
                // Cari field mapping yang mungkin (dinamis)
                const possibleMappingFields = ['part_pk', 'pk', 'id', 'product_id', 'item_id'];
                let mappingField = null;
                
                // Cek field mana yang ada di row pertama dan API pertama
                if (newDefaultValue.length > 0 && items.length > 0) {
                    const firstRow = newDefaultValue[0];
                    const firstApiItem = items[0];
                    
                    for (const field of possibleMappingFields) {
                        if (firstRow[field] !== undefined && firstApiItem.pk !== undefined) {
                            // Untuk API, selalu gunakan 'pk' sebagai target
                            mappingField = field;
                            break;
                        }
                    }
                }
                
                console.log(`[datagrid] Using mapping field: ${mappingField} -> API.pk`);
                
                // Buat mapping berdasarkan field yang ditemukan
                const apiItemsByPk = {};
                items.forEach(apiItem => {
                    if (apiItem && apiItem.pk) {
                        apiItemsByPk[apiItem.pk] = apiItem;
                    }
                });
                console.log(`[datagrid] API items mapped by PK:`, Object.keys(apiItemsByPk));
                
                // Update row dengan data API yang cocok
                newDefaultValue.forEach((row, rowIndex) => {
                    const mappingValue = mappingField ? row[mappingField] : null;
                    const apiItem = mappingValue ? apiItemsByPk[mappingValue] : null;
                    
                    console.log(`[datagrid] Row ${rowIndex}: Product="${row.product_name?.substring(0, 30)}...", ${mappingField}: ${mappingValue}, API match: ${!!apiItem}`);
                    
                    apiComponents.forEach((sc) => {
                        const valKey = sc.apiSource.valueKey || sc.key;
                        const apiValue = apiItem?.[valKey];
                        
                        if (sc.key === "image") {
                            // Replace "unknown" hanya jika ada data API yang valid dan tidak kosong
                            if (apiValue !== undefined && apiValue !== null && apiValue !== "") {
                                console.log(`[datagrid] Row ${rowIndex}: Image updated from "unknown" to "${apiValue}"`);
                                row[sc.key] = apiValue;
                            } else {
                                console.log(`[datagrid] Row ${rowIndex}: Image remains "unknown" (${mappingField}: ${mappingValue}, API value: ${apiValue})`);
                            }
                            // Jika tidak ada data valid, biarkan tetap "unknown"
                        } else {
                            // Untuk field lain, update jika ada data valid
                            if (apiValue !== undefined && apiValue !== null) {
                                row[sc.key] = apiValue;
                            }
                        }
                    });
                });
            }
            // Jika API kosong/null/undefined/array kosong, semua image tetap "unknown"
        });
    }

    // Jika tidak ada data dari query, gunakan defaultValue yang sudah ada
    if (newDefaultValue.length === 0 && component.defaultValue && Array.isArray(component.defaultValue)) {
        // console.log("Using existing defaultValue");
        
        component.defaultValue.forEach((row) => {
            const processedRow = {};
            components.forEach((sc) => {
                if (sc.key === "image") {
                    // Untuk field image, set "unknown" jika kosong/null/undefined
                    processedRow[sc.key] = (row[sc.key] && row[sc.key] !== "" && row[sc.key] !== null) ? row[sc.key] : "unknown";
                } else {
                    // Untuk field lain, ambil nilai asli
                    processedRow[sc.key] = row[sc.key];
                }
            });
            // Tambahkan content HTML
            Object.entries(contentHTMLMap).forEach(([key, html]) => {
                processedRow[key] = html;
            });
            newDefaultValue.push(processedRow);
        });
    }

    // Jika masih tidak ada data sama sekali, buat baris kosong
    if (newDefaultValue.length === 0) {
        const emptyRow = {};
        components.forEach((sc) => {
            if (sc.key === "image") {
                // Field image selalu "unknown" jika tidak ada data
                emptyRow[sc.key] = "unknown";
            } else {
                // Field lain undefined
                emptyRow[sc.key] = undefined;
            }
        });
        // Tambahkan content HTML
        Object.entries(contentHTMLMap).forEach(([key, html]) => {
            emptyRow[key] = html;
        });
        newDefaultValue.push(emptyRow);
    }

    // Final validation: pastikan setiap row memiliki field image dengan value yang tepat
    newDefaultValue.forEach(row => {
        components.forEach(sc => {
            if (sc.key === "image") {
                // Jika field image masih kosong/null/undefined, isi dengan "unknown"
                if (!row[sc.key] || row[sc.key] === null || row[sc.key] === undefined || row[sc.key] === "") {
                    row[sc.key] = "unknown";
                }
            }
        });
    });
    component.defaultValue = newDefaultValue;
    
    // Debug logging untuk melihat hasil akhir
    const imageFields = newDefaultValue.map((row, index) => ({
        rowIndex: index,
        image: row.image,
        hasValidImage: row.image && row.image !== "unknown" && row.image !== ""
    }));
    
    console.log(`[datagrid] Final result: ${newDefaultValue.length} rows processed`);
    console.log(`[datagrid] Image field status:`, imageFields);
    
    //console.log("Final default value for DataGrid component:", component.defaultValue);
    //console.log("Number of rows:", newDefaultValue.length);
}

module.exports = processDataGridComponent;
