// process/editgrid.js

const processSelectComponent = require("./select");
const processSelectBoxesComponent = require("./selectboxes");
const processContentComponent = require("./content");
const processDefaultComponent = require("./default");

function processEditGridComponent(component, queryData, formState, session, apiConfigs, memberResult) {
    const { components } = component;
    const newDefaultValue = [];

    console.log("Processing EditGrid component:", component);

    // First, process all sub-components to populate their data/options
    components.forEach((subComponent) => {
        console.log(`Processing sub-component: ${subComponent.key} (${subComponent.type})`);
        
        switch (subComponent.type) {
            case 'select':
                processSelectComponent(subComponent, queryData, formState, apiConfigs);
                break;
            case 'selectboxes':
                processSelectBoxesComponent(subComponent, formState, apiConfigs, memberResult);
                break;
            case 'content':
                processContentComponent(subComponent, queryData, formState, apiConfigs);
                break;
            default:
                processDefaultComponent(subComponent, queryData, formState, apiConfigs, session);
                break;
        }
    });

    // Create mapping of components by table for query data processing
    const tableComponentMap = {};
    const apiComponentMap = {};
    
    components.forEach((subComponent) => {
        // Group by table for SQL/Graph data
        if (subComponent.table) {
            const table = subComponent.table;
            if (!tableComponentMap[table]) {
                tableComponentMap[table] = [];
            }
            tableComponentMap[table].push(subComponent);
        }
        
        // Group by API source
        if (subComponent.apiSource) {
            const source = subComponent.apiSource.source;
            if (!apiComponentMap[source]) {
                apiComponentMap[source] = [];
            }
            apiComponentMap[source].push(subComponent);
        }
    });

    // Process data from SQL/Graph queries
    if (queryData && queryData.length > 0) {
        console.log("Processing query data for EditGrid:", JSON.stringify(queryData, null, 2));

        queryData.forEach((queryItem) => {
            Object.entries(tableComponentMap).forEach(([table, tableComponents]) => {
                console.log("Processing table:", table);

                // Handle SQL query data
                if (queryItem.sqlQuery?.table === table) {
                    console.log("Processing SQL data for table:", table);
                    queryItem.sqlQuery.data.forEach((item) => {
                        const row = {};
                        tableComponents.forEach((sc) => {
                            if (item[sc.key] !== undefined) {
                                row[sc.key] = item[sc.key];
                            }
                        });

                        if (Object.keys(row).length > 0) {
                            newDefaultValue.push(row);
                        }
                    });
                }

                // Handle Graph query data
                if (queryItem.graph?.[table]) {
                    console.log("Processing graph data for table:", table);
                    queryItem.graph[table].forEach((item) => {
                        const row = {};
                        tableComponents.forEach((sc) => {
                            if (item[sc.key] !== undefined) {
                                row[sc.key] = item[sc.key];
                            }
                        });

                        if (Object.keys(row).length > 0) {
                            newDefaultValue.push(row);
                        }
                    });
                }
            });
        });
    }

    // Process API data to populate rows
    Object.entries(apiComponentMap).forEach(([source, apiComponents]) => {
        const apiData = formState.apiResults?.[source];
        console.log(`Processing API data for source ${source}:`, apiData);
        
        if (apiData) {
            const dataPath = apiComponents[0]?.apiSource?.dataPath || [];
            let items = apiData;

            // Handle both array and single object responses
            const dataItems = Array.isArray(apiData) ? apiData : [apiData];
            
            dataItems.forEach(dataItem => {
                // Navigate through the dataPath if defined
                let processedItems = dataItem;
                for (const path of dataPath) {
                    processedItems = processedItems?.[path] ?? null;
                }

                if (Array.isArray(processedItems)) {
                    processedItems.forEach((item, index) => {
                        // Create or update row
                        let row = newDefaultValue[index] || {};
                        
                        apiComponents.forEach((sc) => {
                            const valueKey = sc.apiSource.valueKey || sc.key;
                            if (item[valueKey] !== undefined) {
                                row[sc.key] = item[valueKey];
                            }
                        });

                        // Ensure row exists in newDefaultValue
                        if (newDefaultValue[index]) {
                            newDefaultValue[index] = { ...newDefaultValue[index], ...row };
                        } else {
                            newDefaultValue.push(row);
                        }
                    });
                } else if (processedItems && typeof processedItems === 'object') {
                    // Handle single object
                    let row = newDefaultValue[0] || {};
                    
                    apiComponents.forEach((sc) => {
                        const valueKey = sc.apiSource.valueKey || sc.key;
                        if (processedItems[valueKey] !== undefined) {
                            row[sc.key] = processedItems[valueKey];
                        }
                    });

                    if (newDefaultValue[0]) {
                        newDefaultValue[0] = { ...newDefaultValue[0], ...row };
                    } else {
                        newDefaultValue.push(row);
                    }
                }
            });
        }
    });

    // If no data from queries or APIs, check existing defaultValue
    if (newDefaultValue.length === 0 && component.defaultValue && Array.isArray(component.defaultValue)) {
        console.log("Using existing defaultValue for EditGrid");
        
        component.defaultValue.forEach((existingRow) => {
            // Validate that the row has meaningful data
            const hasValidData = components.some(sc => {
                const value = existingRow[sc.key];
                return value !== undefined && value !== null && value !== '';
            });

            if (hasValidData) {
                newDefaultValue.push({ ...existingRow });
            }
        });
    }

    // If still no data and openWhenEmpty is true, create one empty row with default values
    if (newDefaultValue.length === 0 && component.openWhenEmpty) {
        const emptyRow = {};
        components.forEach((sc) => {
            // Set default values based on component type
            switch (sc.type) {
                case 'select':
                    emptyRow[sc.key] = sc.defaultValue || '';
                    break;
                case 'number':
                    emptyRow[sc.key] = sc.defaultValue || 0;
                    break;
                case 'selectboxes':
                    emptyRow[sc.key] = sc.defaultValue || {};
                    break;
                default:
                    emptyRow[sc.key] = sc.defaultValue || '';
                    break;
            }
        });
        newDefaultValue.push(emptyRow);
    }

    // Update component's defaultValue
    component.defaultValue = newDefaultValue;

    console.log("Final EditGrid defaultValue:", component.defaultValue);
    console.log("Number of EditGrid rows:", newDefaultValue.length);

    // Process sub-components that might need updates based on the populated data
    components.forEach((subComponent) => {
        // If sub-component has conditional logic or dependencies, process them here
        if (subComponent.conditional || subComponent.customConditional) {
            console.log(`Processing conditional logic for sub-component: ${subComponent.key}`);
            // Add conditional processing logic here if needed
        }
    });
}

module.exports = processEditGridComponent;
