// utils/queryProcessor.js

function processQueryData(data) {
    const processGraphStructure = (item) => {
      const graph = {};
  
      if (item.graph) {
        for (const key in item.graph) {
          if (Array.isArray(item.graph[key])) {
            graph[key] = flattenArrayAndObjects(item.graph[key]);
          } else if (typeof item.graph[key] === "object" && item.graph[key] !== null) {
            graph[key] = flattenCompleteObject(item.graph[key]);
          } else {
            graph[key] = item.graph[key];
          }
        }
        return { ...item, graph };
      }
  
      return flattenCompleteObject(item);
    };
  
    const flattenArrayAndObjects = (arr) => {
      return arr.reduce((flat, item) => {
        if (Array.isArray(item)) {
          return flat.concat(flattenArrayAndObjects(item));
        }
        if (typeof item === "object" && item !== null) {
          return flat.concat(flattenCompleteObject(item));
        }
        return flat.concat(item);
      }, []);
    };
  
    const flattenCompleteObject = (obj) => {
      const result = {};
      const flatten = (current) => {
        for (const key in current) {
          if (typeof current[key] === "object" && current[key] !== null) {
            if (Array.isArray(current[key])) {
              current[key].forEach(flatten);
            } else {
              flatten(current[key]);
            }
          } else {
            result[key] = current[key];
          }
        }
      };
      flatten(obj);
      return result;
    };
  
    if (Array.isArray(data)) {
      return data.map(processGraphStructure);
    }
    return [processGraphStructure(data)];
  }
  
  module.exports = { processQueryData };